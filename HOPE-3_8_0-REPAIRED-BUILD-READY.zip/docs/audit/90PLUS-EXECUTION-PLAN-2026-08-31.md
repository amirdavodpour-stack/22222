# HOPE 90+ Execution Plan — 2026-08-31

## Target
Raise every scorecard dimension to at least 90/100 while preserving the current security and financial invariants. No score is upgraded merely because a contract exists; runtime evidence is required for environment-dependent gates.

## Waves

### Wave A — Reliability foundation (started)
- S3 upload intent size binding and completion verification.
- Durable mobile upload queue and safe GET retry policy.
- Notification delivery ledger and machine-readable outbox failure metadata.
- Backup checksum generation/verification.
- Certification evidence pack and release gate.

### Wave B — Trust & marketplace integrity
- Reviews/ratings with one-per-party-per-job semantics.
- Reputation aggregation with recency and dispute penalties.
- First-class dispute lifecycle: OPEN → REVIEWING → RESOLVED/REJECTED.
- Cancel/rework policies with actor authorization, financial effects, and audit trails.
- Identity-minimization rules across all employer/provider surfaces.

### Wave C — Financial production
- Real PSP adapter in staging and production.
- Signed webhook replay/duplicate protection.
- Full release/refund/reconciliation evidence.
- Wallet ledger, withdrawals and payout state machine (only after PSP boundary is proven).

### Wave D — Storage/notification runtime certification
- HTTPS S3 lifecycle: presign → upload → complete → HEAD → signature validation → cleanup.
- Push/email provider staging certification with retry/dead-letter evidence.
- Expired intent garbage collection and orphan object reconciliation.

### Wave E — Mobile runtime certification
- Flutter 3.47 analyze/test/build.
- Android emulator lifecycle test.
- Offline/reconnect/token-refresh/upload/notification scenarios.
- At least one physical release-candidate device check.
- Accessibility and localization runtime sweep.

### Wave F — Performance & operations
- Node 24 performance smoke in CI with persisted p95/p99 evidence.
- Multi-instance resilience drill.
- PostgreSQL isolated DR restore with RTO evidence.
- External metrics, logs, tracing and alert delivery.

### Wave G — Final release certification
All below must be PASS for production release: backend/mobile quality, PSP, S3, push/email, DR restore, performance, emulator/device certification, production environment validation, SBOM/provenance/checksum.

## Hard rule
Environment-dependent score increases are only allowed after the corresponding evidence artifact exists and the release commit matches the evidence commit.

## Execution status — 2026-08-31

### Completed in this working session
- Wave C1 financial-dispute hardening: PostgreSQL dispute resolution is now implemented transactionally, linked to payment outbox events, and retryable after terminal provider failure.
- Wave A reliability controls implemented and regression-tested.
- Wave B trust controls implemented: reviews, reputation, dispute freeze, rework, cancellation guard, provider verification.
- Wave B financial control-plane path implemented: admin dispute refund/release actions are idempotent and ledger-aware; unsupported split settlement is fail-closed.
- Mobile Trust & Resolution panel added to the transaction surface.
- Current local backend quality sweep: syntax check PASS; fast contract suite PASS; product suite PASS; provider integration PASS; failure-injection PASS; backup/DR contract suite PASS; reconciliation PASS; performance health smoke PASS.

### Not yet certified
- PostgreSQL runtime / multi-instance execution in this sandbox: no PostgreSQL service available.
- Real S3 lifecycle: requires deployed bucket/credentials.
- Real push/email delivery: requires provider endpoint/credentials and device runtime.
- Flutter 3.47 / Android 36 build and physical-device smoke: Flutter/Android SDK unavailable in this sandbox.
- Production PSP: adapter contract is present, but production certification requires a real PSP facade, credentials and webhook evidence.

### Target gates
| Gate | Target | Evidence required |
|---|---:|---|
| Trust & reputation | 930/1000 | settled review E2E, abuse/race tests, reputation calculations, dispute lifecycle evidence |
| Financial integrity | 940/1000 | PSP create/hold/release/refund, webhook replay test, reconciliation batch, balanced ledger evidence |
| Storage | 930/1000 | real S3 presign/upload/complete/HEAD, orphan cleanup and size-binding evidence |
| Notifications | 930/1000 | push/email staging delivery, retry/dead-letter and device receipt evidence |
| Mobile | 920/1000 | Flutter analyze/test, release APK, emulator + physical-device smoke, RTL/a11y sweep |
| Performance | 920/1000 | Node 24 staging p95/p99 and 5xx evidence under bounded load |
| DR/resilience | 930/1000 | isolated PostgreSQL restore, RTO/RPO measurement, replica-failure drill |
| Production readiness | 930/1000 | all above gates + environment validation + provenance/SBOM/checksum |

