import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import '../evidence/evidence_picker.dart';
import '../../core/uploads/upload_queue.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_error_presenter.dart';
import '../../core/auth/auth_controller.dart';
import '../../core/ui/brand.dart';
import 'trust_panel.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';

class TransactionPage extends StatefulWidget {
  const TransactionPage({super.key, required this.api, required this.jobId});
  final ApiClient api;
  final String jobId;
  @override
  State<TransactionPage> createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  Map<String, dynamic>? payment;
  bool loading = true;
  String? error;
  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    try {
      if (mounted) setState(() => error = null);
      final data = await widget.api
          .request('GET', '/payments/jobs/${widget.jobId}', auth: true);
      if (mounted) setState(() => payment = Map<String, dynamic>.from(data));
    } catch (e) {
      if (mounted) setState(() => error = apiErrorMessage(e, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c));
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> action(String path, {Map<String, dynamic>? body}) async {
    setState(() => loading = true);
    try {
      await widget.api.request('POST', path, auth: true, body: body);
      await refresh();
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(HopeCopy.of(context).copy_operation_completed_66dd356)));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(apiErrorMessage(e, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c))));
      }
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading && payment == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (error != null && payment == null) {
      return Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(error!, textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: loading ? null : refresh, child: Text(HopeCopy.of(context).copy_retry_49f3eba))]))));
    }
    final status = payment?['status'] ?? 'NO_TRANSACTION';
    final job = payment?['job'] is Map ? Map<String, dynamic>.from(payment!['job'] as Map) : null;
    final isOwner = job != null && context.read<AuthController>().user?['id']?.toString() == job['ownerId']?.toString();
    return Directionality(
      textDirection: Localizations.localeOf(context).languageCode == 'en' ? TextDirection.ltr : TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(leading: IconButton(onPressed: () => Navigator.maybePop(context), icon: Icon(Localizations.localeOf(context).languageCode == 'en' ? Icons.arrow_back_rounded : Icons.arrow_forward_rounded), tooltip: HopeCopy.of(context).copy_back_6e09f79), title: Text(HopeCopy.of(context).copy_transaction_7e0ea3b)),
        body: ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 40), children: [
          Row(children: [const HopeMark(size: 38), const Spacer(), StatusPill(status == 'NO_TRANSACTION' ? HopeCopy.of(context).copy_no_payment_1337b58 : '$status', color: status == 'RELEASED' ? AppColors.success : AppColors.primary)]),
          const SizedBox(height: 20),
          if (job != null) Text('${job['title'] ?? HopeCopy.of(context).copy_transaction_details_d5a9152}', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 14),
          HopeSurface(padding: const EdgeInsets.all(18), child: Column(children: [
            Row(children: [Expanded(child: Text(HopeCopy.of(context).copy_payment_status_e1b6f0c, style: Theme.of(context).textTheme.bodyMedium)), Text('$status', style: Theme.of(context).textTheme.titleMedium)]),
            const SizedBox(height: 14),
            Row(children: [Expanded(child: Text(HopeCopy.of(context).copy_amount_6400812, style: Theme.of(context).textTheme.bodyMedium)), Text('${payment?['amount'] ?? '-'}', style: Theme.of(context).textTheme.titleMedium)]),
            const SizedBox(height: 14),
            Row(children: [Expanded(child: Text(HopeCopy.of(context).copy_reference_aa63360, style: Theme.of(context).textTheme.bodyMedium)), Flexible(child: Text('${payment?['providerRef'] ?? '—'}', textAlign: TextAlign.left, style: Theme.of(context).textTheme.titleMedium))]),
          ])),
          if (payment?['fees'] is Map) ...[
            const SizedBox(height: 12),
            HopeSurface(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(HopeCopy.of(context).copy_financial_details_f24007d, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              _moneyRow(HopeCopy.of(context).copy_base_amount_82586c0, payment!['fees']['baseAmount']),
              _moneyRow(HopeCopy.of(context).copy_employer_fee_3a30b60, payment!['fees']['employerFee']),
              _moneyRow(HopeCopy.of(context).copy_worker_fee_85a35aa, payment!['fees']['workerFee']),
              const Divider(height: 20),
              _moneyRow(HopeCopy.of(context).copy_employer_charge_9740283, payment!['fees']['employerCharge'], strong: true),
              _moneyRow(HopeCopy.of(context).copy_worker_payout_45f6bb9, payment!['fees']['providerPayout'], strong: true),
            ])),
          ],
          const SizedBox(height: 14),
          if (status == 'NO_TRANSACTION') FilledButton.icon(onPressed: loading ? null : () => action('/payments/fund/${widget.jobId}', body: {'idempotencyKey': 'mobile-${DateTime.now().millisecondsSinceEpoch}'}), icon: const Icon(Icons.account_balance_wallet_rounded), label: Text(HopeCopy.of(context).copy_fund_payment_c223336)),
          if (status == 'HELD' && isOwner) OutlinedButton.icon(onPressed: loading ? null : () => action('/payments/refund/${widget.jobId}', body: const {}), icon: const Icon(Icons.undo_rounded), label: Text(HopeCopy.of(context).copy_request_refund_c55b9aa)),
          if (job != null) ...[
            TrustPanel(api: widget.api, jobId: widget.jobId, job: job, payment: payment ?? const {}),
            const SizedBox(height: 14),
            EvidenceActions(api: widget.api, jobId: widget.jobId, job: {...job, 'paymentStatus': payment?['paymentStatus'] ?? payment?['status']}, onChanged: refresh),
          ],
        ]),
      ),
    );
  }

}

Widget _moneyRow(String label, dynamic value, {bool strong = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [Expanded(child: Text(label)), Text('${value ?? '—'}', style: TextStyle(fontWeight: strong ? FontWeight.w800 : FontWeight.w500))]),
    );

class EvidenceActions extends StatefulWidget {
  const EvidenceActions(
      {super.key,
      required this.api,
      required this.jobId,
      required this.job,
      required this.onChanged});
  final ApiClient api;
  final String jobId;
  final Map<String, dynamic> job;
  final VoidCallback onChanged;
  @override
  State<EvidenceActions> createState() => _EvidenceActionsState();
}

class _EvidenceActionsState extends State<EvidenceActions> {
  bool busy = false;
  Future<void> post(String path, {Map<String, dynamic>? body}) async {
    setState(() => busy = true);
    try {
      await widget.api.request('POST', path, auth: true, body: body);
      widget.onChanged();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(apiErrorMessage(e, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c))));
      }
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final st = '${widget.job['status'] ?? ''}';
    final paymentStatus = '${widget.job['paymentStatus'] ?? ''}';
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Divider(height: 32),
      Text(HopeCopy.of(context).copy_work_execution_cb0edb9, style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      if (st == 'FUNDED')
        FilledButton(
            onPressed: busy ? null : () => post('/jobs/${widget.jobId}/start'),
            child: Text(HopeCopy.of(context).copy_start_work_51d8317)),
      if (st == 'IN_PROGRESS') ...[
        OutlinedButton(
            onPressed: busy
                ? null
                : () => showDialog(
                    context: context,
                    builder: (_) => EvidenceDialog(
                        api: widget.api,
                        jobId: widget.jobId,
                        onDone: widget.onChanged)),
            child: Text(HopeCopy.of(context).copy_submit_evidence_bf38455)),
        FilledButton(
            onPressed:
                busy ? null : () => post('/jobs/${widget.jobId}/deliver'),
            child: Text(HopeCopy.of(context).copy_deliver_work_49b9e5e))
      ],
      if (st == 'DELIVERED' || st == 'UNDER_REVIEW')
        FilledButton(
            onPressed: busy ? null : () => post('/jobs/${widget.jobId}/accept'),
            child: Text(HopeCopy.of(context).copy_accept_delivery_195e8bd)),
      if (st == 'COMPLETED' && paymentStatus == 'RELEASE_PENDING' && context.read<AuthController>().user?['id']?.toString() == widget.job['ownerId']?.toString())
        FilledButton(
            onPressed:
                busy ? null : () => post('/payments/release/${widget.jobId}'),
            child: Text(HopeCopy.of(context).copy_settle_payment_82af0e6)),
      if (st == 'COMPLETED' && paymentStatus == 'RELEASED')
        Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(HopeCopy.of(context).copy_payment_has_been_settled_f8f8f83)),
      if (st == 'SETTLED')
        Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(HopeCopy.of(context).copy_this_transaction_is_settled_04f8174))
    ]);
  }
}

class EvidenceDialog extends StatefulWidget {
  const EvidenceDialog(
      {super.key,
      required this.api,
      required this.jobId,
      required this.onDone});
  final ApiClient api;
  final String jobId;
  final VoidCallback onDone;
  @override
  State<EvidenceDialog> createState() => _EvidenceDialogState();
}

class _EvidenceDialogState extends State<EvidenceDialog> {
  final uri = TextEditingController();
  final notes = TextEditingController();
  bool busy = false;
  File? file;
  late final UploadQueue queue;
  @override
  void initState() {
    super.initState();
    queue = UploadQueue(widget.api);
  }

  @override
  void dispose() {
    uri.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> pick() async {
    final selected = await EvidencePicker().pickFile();
    if (mounted && selected != null) setState(() => file = selected);
  }

  Future<void> send() async {
    setState(() => busy = true);
    try {
      String evidenceUri = uri.text.trim();
      if (file != null) {
        // Retry with backoff via the upload queue instead of a single
        // direct attempt, so a flaky connection doesn't force the user
        // to re-pick the file and resubmit from scratch.
        final uploaded = await queue.uploadNowWithRetry('/storage/upload', file!);
        if (uploaded is Map && uploaded['key'] is String) {
          evidenceUri = 'storage://${uploaded['key']}';
        }
      }
      if (evidenceUri.isEmpty) {
        throw StateError('Evidence file or URI is required');
      }
      await widget.api
          .request('POST', '/jobs/${widget.jobId}/evidence', auth: true, body: {
        'uri': evidenceUri,
        'notes': notes.text.trim(),
        'type': file != null ? 'FILE' : 'DELIVERY_LINK'
      });
      if (mounted) {
        Navigator.pop(context);
        widget.onDone();
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(HopeCopy.of(context).copy_could_not_submit_evidence_9d09019)));
      }
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
          title: Row(children: [const HopeIconTile(Icons.upload_file_rounded, size: 42), const SizedBox(width: 10), Expanded(child: Text(HopeCopy.of(context).copy_submit_evidence_bf38455))]),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            OutlinedButton.icon(
                onPressed: busy ? null : pick,
                icon: const Icon(Icons.attach_file),
                label: Text(
                    file == null ? 'انتخاب فایل' : file!.path.split('/').last)),
            TextField(
                controller: uri,
                decoration:
                    InputDecoration(labelText: HopeCopy.of(context).copy_link_uri_optional_1d2307a)),
            TextField(
                controller: notes,
                decoration: InputDecoration(labelText: HopeCopy.of(context).copy_description_24d1e57))
          ])),
          actions: [
            TextButton(
                onPressed: busy ? null : () => Navigator.pop(context),
                child: Text(HopeCopy.of(context).copy_cancel_9955c4b)),
            FilledButton(
                onPressed: busy ? null : send, child: Text(HopeCopy.of(context).copy_submit_201d121))
          ]);
}
