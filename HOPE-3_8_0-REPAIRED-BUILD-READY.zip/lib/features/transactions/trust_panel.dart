import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/auth/auth_controller.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_error_presenter.dart';
import '../../core/ui/hope_l10n.dart';
import '../../core/ui/components.dart';

class TrustPanel extends StatefulWidget {
  const TrustPanel({super.key, required this.api, required this.jobId, required this.job, required this.payment});
  final ApiClient api;
  final String jobId;
  final Map<String, dynamic> job;
  final Map<String, dynamic> payment;

  @override
  State<TrustPanel> createState() => _TrustPanelState();
}

class _TrustPanelState extends State<TrustPanel> {
  bool loading = true;
  bool busy = false;
  Map<String, dynamic> reviewData = const {};
  Map<String, dynamic>? dispute;
  Map<String, dynamic>? rework;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final reviews = await widget.api.request('GET', '/jobs/${widget.jobId}/reviews');
      final reviewMap = reviews is Map ? Map<String, dynamic>.from(reviews) : <String, dynamic>{};
      Map<String, dynamic>? disputeMap;
      Map<String, dynamic>? reworkMap;
      try {
        final d = await widget.api.request('GET', '/jobs/${widget.jobId}/dispute', auth: true);
        if (d is List && d.isNotEmpty && d.first is Map) {
          disputeMap = Map<String, dynamic>.from(d.first as Map);
        }
      } catch (_) {}
      try {
        final r = await widget.api.request('GET', '/jobs/${widget.jobId}/rework', auth: true);
        if (r is Map) reworkMap = Map<String, dynamic>.from(r);
      } catch (_) {}
      if (mounted) {
        setState(() {
          reviewData = reviewMap;
          dispute = disputeMap;
          rework = reworkMap;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _post(String path, Map<String, dynamic> body) async {
    setState(() => busy = true);
    try {
      await widget.api.request('POST', path, auth: true, body: body);
      await _load();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(apiErrorMessage(error, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c))),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _review() async {
    final rating = ValueNotifier<int>(5);
    final comment = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(HopeCopy.of(dialogContext).copy_leave_feedback),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ValueListenableBuilder<int>(
            valueListenable: rating,
            builder: (_, value, __) => Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) => IconButton(
                    tooltip: '${index + 1}',
                    onPressed: () => rating.value = index + 1,
                    icon: Icon(index < value ? Icons.star_rounded : Icons.star_border_rounded),
                  )),
            ),
          ),
          TextField(
            controller: comment,
            maxLines: 4,
            maxLength: 1000,
            decoration: InputDecoration(
              labelText: HopeCopy.of(dialogContext).copy_optional_note,
              hintText: HopeCopy.of(dialogContext).copy_feedback_hint,
            ),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(HopeCopy.of(dialogContext).copy_cancel_9955c4b)),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(HopeCopy.of(dialogContext).copy_submit_201d121)),
        ],
      ),
    );
    if (submitted == true) {
      await _post('/jobs/${widget.jobId}/reviews', {'rating': rating.value, 'comment': comment.text.trim()});
    }
    comment.dispose();
    rating.dispose();
  }

  Future<void> _dispute() async {
    final reason = TextEditingController();
    final details = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(HopeCopy.of(dialogContext).copy_open_dispute),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            controller: reason,
            maxLength: 120,
            decoration: InputDecoration(labelText: HopeCopy.of(dialogContext).copy_reason),
          ),
          TextField(
            controller: details,
            maxLines: 4,
            maxLength: 2000,
            decoration: InputDecoration(labelText: HopeCopy.of(dialogContext).copy_details),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(HopeCopy.of(dialogContext).copy_cancel_9955c4b)),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(HopeCopy.of(dialogContext).copy_submit_201d121)),
        ],
      ),
    );
    if (submitted == true) {
      await _post('/jobs/${widget.jobId}/dispute', {'reason': reason.text.trim(), 'details': details.text.trim()});
    }
    reason.dispose();
    details.dispose();
  }

  Future<void> _rework() async {
    final reason = TextEditingController();
    final submitted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(HopeCopy.of(dialogContext).copy_request_rework),
        content: TextField(
          controller: reason,
          maxLength: 120,
          decoration: InputDecoration(labelText: HopeCopy.of(dialogContext).copy_rework_reason),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: Text(HopeCopy.of(dialogContext).copy_cancel_9955c4b)),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(HopeCopy.of(dialogContext).copy_submit_201d121)),
        ],
      ),
    );
    if (submitted == true) await _post('/jobs/${widget.jobId}/rework', {'reason': reason.text.trim()});
    reason.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final status = '${widget.job['status'] ?? ''}';
    final userId = context.read<AuthController>().user?['id']?.toString();
    final isOwner = userId != null && userId == '${widget.job['ownerId'] ?? ''}';
    final isProvider = userId != null && userId == '${widget.job['providerId'] ?? ''}';
    final summary = reviewData['summary'] is Map ? Map<String, dynamic>.from(reviewData['summary'] as Map) : const <String, dynamic>{};
    final reviews = reviewData['reviews'] is List ? reviewData['reviews'] as List : const [];
    final canReview = status == 'SETTLED' && (isOwner || isProvider) && reviews.length < 2;
    final canDispute = ['IN_PROGRESS', 'DELIVERED', 'UNDER_REVIEW'].contains(status) && (isOwner || isProvider) && dispute == null;
    final canRework = isOwner && ['DELIVERED', 'UNDER_REVIEW'].contains(status) && dispute == null && rework == null;

    if (loading && reviewData.isEmpty && dispute == null && rework == null) {
      return const Padding(padding: EdgeInsets.all(12), child: Center(child: LinearProgressIndicator()));
    }

    return HopeSurface(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          const HopeIconTile(Icons.verified_user_outlined, filled: true),
          const SizedBox(width: 10),
          Expanded(child: Text(HopeCopy.of(context).copy_trust_resolution_title, style: Theme.of(context).textTheme.titleMedium)),
          if (busy) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
        ]),
        const SizedBox(height: 10),
        if (summary.isNotEmpty)
          Text(
            '${HopeCopy.of(context).copy_average_feedback}: ${summary['average'] ?? 0}/5 • ${summary['count'] ?? 0} ${HopeCopy.of(context).copy_reviews}',
          ),
        if (dispute != null) ...[
          const SizedBox(height: 10),
          StatusPill(HopeCopy.of(context).copy_active_dispute, color: Colors.orange, icon: Icons.gavel_rounded),
          const SizedBox(height: 6),
          Text('${dispute!['reason'] ?? ''}', style: Theme.of(context).textTheme.bodyMedium),
        ],
        if (rework != null) ...[
          const SizedBox(height: 10),
          StatusPill(HopeCopy.of(context).copy_rework_requested, color: Colors.orange, icon: Icons.build_circle_outlined),
          const SizedBox(height: 6),
          Text('${rework!['reason'] ?? ''}', style: Theme.of(context).textTheme.bodyMedium),
        ],
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          if (canReview) OutlinedButton.icon(onPressed: busy ? null : _review, icon: const Icon(Icons.star_outline_rounded), label: Text(HopeCopy.of(context).copy_leave_feedback)),
          if (canDispute) OutlinedButton.icon(onPressed: busy ? null : _dispute, icon: const Icon(Icons.gavel_outlined), label: Text(HopeCopy.of(context).copy_open_dispute)),
          if (canRework) OutlinedButton.icon(onPressed: busy ? null : _rework, icon: const Icon(Icons.build_outlined), label: Text(HopeCopy.of(context).copy_request_rework)),
        ]),
      ]),
    );
  }
}
