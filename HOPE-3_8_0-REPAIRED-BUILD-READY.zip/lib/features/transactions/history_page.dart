import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/auth/auth_controller.dart';
import '../../core/network/api_client.dart';
import '../../core/ui/components.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key, required this.api});
  final ApiClient api;
  @override State<HistoryPage> createState() => _HistoryPageState();
}
class _HistoryPageState extends State<HistoryPage> {
  Future<dynamic>? _future;
  String _filter = 'همه';
  @override void didChangeDependencies() {
    super.didChangeDependencies();
    if (_future == null && !context.read<AuthController>().isGuest) _future = widget.api.request('GET','/jobs/mine',auth:true);
  }
  @override Widget build(BuildContext context) {
    if (context.watch<AuthController>().isGuest) return const Scaffold(body: Center(child: Text('برای مشاهده تاریخچه وارد حساب شوید.')));
    const filters = ['همه','درخواست‌ها','فرصت‌ها','فعالیت‌ها','تراکنش‌ها'];
    return Scaffold(
      appBar: AppBar(title: const Text('تاریخچه')),
      body: RefreshIndicator(
        onRefresh: () async { setState(() => _future = widget.api.request('GET','/jobs/mine',auth:true)); await _future!.catchError((_) {}); },
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 30),
          children: [
            Text('رویدادهای اخیر', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 5),
            Text('درخواست‌ها، فرصت‌ها، فعالیت‌ها و تراکنش‌ها را به ترتیب زمانی ببینید.', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 14),
            SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, children: filters.map((f) => Padding(
              padding: const EdgeInsets.only(left: 8), child: ChoiceChip(label: Text(f), selected: _filter == f, onSelected: (_) => setState(() => _filter = f)),
            )).toList())),
            const SizedBox(height: 14),
            FutureBuilder<dynamic>(future: _future, builder: (context,snap) {
              if (snap.connectionState != ConnectionState.done) return const Padding(padding: EdgeInsets.all(50), child: Center(child: CircularProgressIndicator()));
              if (snap.hasError) return const EmptyState(icon: Icons.cloud_off_outlined, title: 'تاریخچه بارگذاری نشد', message: 'اتصال را بررسی کنید و دوباره تلاش کنید.');
              final list = snap.data is List ? (snap.data as List) : const [];
              if (list.isEmpty) return const EmptyState(icon: Icons.history_rounded, title: 'هنوز رویدادی نیست', message: 'با اولین فعالیت شما، تاریخچه اینجا ساخته می‌شود.');
              return Column(children: list.map<Widget>((raw) {
                final m = raw is Map ? raw : const {};
                return Padding(padding: const EdgeInsets.only(bottom: 9), child: HopeSurface(padding: const EdgeInsets.all(14), child: Row(children: [
                  const HopeIconTile(Icons.timeline_rounded, filled: true), const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${m['title'] ?? 'فعالیت کاری'}', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 3), Text('${m['status'] ?? 'رویداد ثبت شد'}', style: Theme.of(context).textTheme.bodyMedium),
                  ])),
                ])));
              }).toList());
            })
          ],
        ),
      ),
    );
  }
}
