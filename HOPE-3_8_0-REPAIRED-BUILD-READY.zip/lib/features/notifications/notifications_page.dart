import 'package:flutter/material.dart';
import '../../core/ui/hope_l10n.dart';
import '../../core/network/api_client.dart';
import '../../core/network/api_error_presenter.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key, required this.api});
  final ApiClient api;
  @override State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<dynamic> items = const [];
  bool loading = true;
  String? error;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await widget.api.request('GET', '/notifications', auth: true);
      final map = data is Map ? data : <String,dynamic>{};
      if (!mounted) return;
      setState(() { items = (map['items'] as List?) ?? const []; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e.toString(); loading = false; });
    }
  }
  Future<void> _read(String id) async {
    try { await widget.api.request('POST', '/notifications/$id/read', auth: true); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiErrorMessage(e, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c)))); return; }
    await _load();
  }
  Future<void> _readAll() async {
    try { await widget.api.request('POST', '/notifications/read-all', auth: true); } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(apiErrorMessage(e, fallback: HopeCopy.of(context).copy_operation_failed_eb38c4c)))); return; }
    await _load();
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(HopeCopy.of(context).copy_notifications_370b4a1), actions: [IconButton(onPressed: items.isEmpty ? null : _readAll, icon: const Icon(Icons.done_all_rounded), tooltip: HopeCopy.of(context).copy_mark_all_read_500a31c)]),
    body: RefreshIndicator(onRefresh: _load, child: loading
      ? ListView(children: const [SizedBox(height: 280), Center(child: CircularProgressIndicator())])
      : error != null
        ? ListView(padding: const EdgeInsets.all(24), children: [Text(HopeCopy.of(context).copy_could_not_load_notifications_a904a88), const SizedBox(height: 12), FilledButton(onPressed:_load, child:Text(HopeCopy.of(context).copy_retry_49f3eba))])
        : items.isEmpty
          ? ListView(padding: const EdgeInsets.all(24), children: [const SizedBox(height: 80), const Icon(Icons.notifications_none_rounded, size: 64), const SizedBox(height: 16), Center(child: Text(HopeCopy.of(context).copy_you_have_no_new_notifications_45f9685))])
          : ListView.separated(padding: const EdgeInsets.fromLTRB(16,16,16,32), itemCount: items.length, separatorBuilder:(_,__)=>const SizedBox(height:8), itemBuilder:(context,index){final n=Map<String,dynamic>.from(items[index] as Map); final unread=n['readAt']==null; return Card(child: InkWell(onTap:unread?()=>_read('${n['id']}'):null, borderRadius:BorderRadius.circular(18), child: Padding(padding:const EdgeInsets.all(16), child:Row(crossAxisAlignment:CrossAxisAlignment.start, children:[Icon(unread?Icons.notifications_active_rounded:Icons.notifications_none_rounded),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${n['title'] ?? ''}',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:4),Text('${n['body'] ?? ''}'),if(unread) ...[const SizedBox(height:7),Text(HopeCopy.of(context).copy_tap_to_mark_as_read_5c9917a,style:Theme.of(context).textTheme.labelMedium)]]))]))));})
    ),
  );
}
