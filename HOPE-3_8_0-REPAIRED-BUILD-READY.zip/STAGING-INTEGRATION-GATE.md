# Staging Integration Gate

This gate is intentionally stronger than static topology checks.

## What it proves when Docker is available

1. PostgreSQL and MinIO become healthy before the API replicas start.
2. Migrations and seed run once in `staging-init`.
3. The gateway can reach **both** API replicas (`api1` and `api2`).
4. A user registered through the gateway can be read through the authenticated account export endpoint on **each** replica, proving application state is shared through PostgreSQL rather than process-local memory.
5. Seeded categories are reachable through the gateway.

## Command

```bash
./tools/staging-local.sh
```

The script exits non-zero when Docker/Compose is unavailable or when any integration assertion fails.
