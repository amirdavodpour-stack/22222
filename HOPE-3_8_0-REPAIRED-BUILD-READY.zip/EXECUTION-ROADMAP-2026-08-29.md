
## Wave 10 — Observability & performance evidence
- [x] Add p95/p99 latency budgets to staging operational health gate.
- [x] Run real staging performance smoke (500 requests / 50 concurrency) before certification PASS.
- [x] Persist machine-readable performance evidence with staging certification artifacts.
- [ ] Add external metrics/alert sink and distributed tracing in the real environment.
# HOPE Execution Roadmap — 2026-08-29

## هدف

بردن پروژه از وضعیت فعلی حدود 81/100 به سطح 90+ با تمرکز بر production readiness، integration واقعی، runtime certification و operational maturity؛ بدون افزودن feature غیرضروری تا زمانی که release path اثبات شود.

## اصول اجرا

1. امتیازدهی بر اساس implementation، تست و رفتار قابل‌اثبات است؛ audit/reportهای قبلی معیار امتیاز نیستند.
2. هر wave باید با یک regression gate تمام شود.
3. mock/simulator فقط برای contract و development است؛ release readiness به integration واقعی وابسته است.
4. هیچ secret یا credential واقعی داخل repository قرار نمی‌گیرد.

## Wave 1 — Runtime & Environment Consistency

**وضعیت: انجام شد**

- Node runtime در package metadata، `.nvmrc`، Docker و GitHub Actions روی Node 24 هم‌تراز شد.
- local staging از `NODE_ENV=production` به `NODE_ENV=staging` تفکیک شد تا MinIO داخلی HTTP با production HTTPS policy متناقض نباشد.
- production image یک entrypoint دارد که قبل از startup، production environment contract را fail-closed اعتبارسنجی می‌کند.
- regression test برای جلوگیری از version drift اضافه شد.
- production release workflow اکنون backend Docker image نهایی را نیز build می‌کند.

## Wave 2 — Integration & Resilience Hardening

**وضعیت: انجام شد**

- payment webhook adapter برای failureهای transient شامل 429 و 5xx و timeout retry محدود دارد.
- retry از همان idempotency key استفاده می‌کند تا عملیات مالی قابل تکرار باشد.
- runtime integration test برای retry behavior اضافه شد.
- gateهای security/release/staging/runtime دوباره اجرا شدند.
- version/runtime consistency و production env fail-closed در CI و startup enforce شدند.

## Wave 3 — Real External Integration

**وضعیت: در حال انجام**

- مرز provider برای notification push/email از worker جدا شد و retry محدودِ HTTPS با idempotency key اضافه شد.
- تست runtime برای 503 → retry → success اضافه شد.
- اتصال PSP واقعی در staging و اجرای create/hold/release/refund با webhook واقعی (باقی‌مانده).
- اتصال S3 واقعی با HTTPS و اجرای presigned upload/complete/validate (باقی‌مانده).
- اتصال push/email provider واقعی و تأیید retry/dead-letter behavior (adapter و retry آماده؛ provider واقعی باقی‌مانده).
- اجرای E2E محصول با endpointهای واقعی staging.

## Wave 4 — Mobile Runtime Certification

- Android emulator certification روی CI.
- تست کامل lifecycle: auth → publish → offer → funding → execution → evidence → delivery → settlement.
- تست reconnect/offline و token refresh.
- تست malformed responses، permission، upload و notification runtime.
- حداقل یک device واقعی برای release candidate.

## Wave 5 — Observability & Operations

- centralized logs
- external metrics sink
- tracing
- alert thresholds
- incident correlation با request ID
- operational dashboard برای health/payment/outbox/provider failures

## Wave 6 — Final Release Gate

Release فقط زمانی مجاز است که:

- backend quality gates سبز باشند
- mobile analyze/test سبز باشد
- Docker image build سبز باشد
- staging E2E سبز باشد
- S3/PSP/notification integration سبز باشد
- DR restore drill سبز باشد
- Android certification سبز باشد
- production environment validator سبز باشد
- provenance و checksum تولید شده باشند

## Baseline بعد از Wave 1 و 2

- Fast backend contract suite: **83/83 PASS**
- Payment provider runtime integration: **2/2 PASS**
- Release-hardening/runtime/staging targeted contracts: **12/12 PASS**
- Production environment positive validation: **PASS**

## محدودیت فعلی محیط بررسی

در این محیط Flutter SDK و Docker daemon در دسترس نبودند؛ بنابراین build واقعی Flutter/Android و build واقعی Docker image اینجا اجرا نشدند و فقط contract/runner checks و workflow enforcement اصلاح و تست شدند. این موارد باید در GitHub Actions یا محیط CI واقعی certify شوند.

## Wave 3 progress checkpoint

- Added a dedicated notification provider boundary with HTTPS delivery, bounded transient retry, request timeout, and stable idempotency keys.
- Wired outbox PUSH/EMAIL delivery through that boundary.
- Added runtime provider integration coverage using an ephemeral HTTPS test server.
- Added notification provider integration to `npm run test:provider`.
- Regression results: `npm run check` PASS; provider suite 3/3 PASS; fast suite 83/83 PASS; contract suite 40/40 PASS; backup and staging-contract suites PASS.
- `npm run test:offline` advanced through test 93 before the execution time window expired; no assertion failure was reported before timeout.

## Next execution target

1. Real staging S3 HTTPS certification.
2. Real PSP webhook certification (create/release/refund + signed webhook + duplicate delivery).
3. Real push/email provider certification with retry and terminal-failure evidence.
4. Full staging product E2E through an HTTPS deployment.
5. Android emulator certification and offline/reconnect/token-refresh scenarios.
6. External metrics/logging/tracing and alert thresholds.


## Wave 4 — Staging asynchronous workflow hardening

Status: IMPLEMENTED

- Product smoke now accepts the API's synchronous or asynchronous payment responses (200/201/202).
- The smoke test polls the authoritative payment endpoint until `HELD` and `RELEASED` instead of assuming the outbox worker completes inline.
- This prevents a false-negative staging gate when provider calls are correctly deferred to the outbox.
- The next gate is real staging/provider execution and Android emulator certification.


## Wave 4B — Staging operational gate

Status: IMPLEMENTED

- Added `tools/staging-operational-gate.mjs`.
- The gate verifies `/live`, `/ready`, `/health`, authenticated `/metrics`, recent 5xx rate, slow-request rate, database health, and outbox counters.
- Production-release CI runs this gate after the end-to-end staging product workflow.
- This turns observability from passive telemetry into an explicit release criterion.

## Wave 5 — Android runtime/release certification hardening

- Added `tools/android-release-contract.sh` to enforce cleartext denial, SDK baselines, pilot-vs-production signing boundaries, and unexpected HTTP endpoint detection.
- Added Java 17 setup to Android-capable CI jobs for reproducible Gradle execution.
- Strengthened device integration smoke to require HTTPS in CI mode.


## Wave 6 execution update — 2026-08-29

Status: IMPLEMENTED

- Provider failure injection added and green.
- Payment 503 exhaustion is bounded to configured attempts.
- Notification permanent 4xx failure is not retried.
- Staging resilience workflow now executes the failure-injection gate.

Next: real external staging integration (HTTPS S3, PSP, notification), then device/runtime certification and DR drill on disposable infrastructure.

- DR restore drill now fails closed on restore errors and verifies required core tables plus a live SQL query after restore.

## Wave 7 — Android runtime certification hardening — 2026-08-29

Status: IMPLEMENTED

- Extended `integration_test/app_smoke_test.dart` beyond boot/live/category checks to cover runtime registration, authenticated provider-profile access, and refresh-token rotation on the Android device process.
- Added `tools/android-runtime-cert-contract.sh` to fail closed unless the device certification endpoint is an HTTPS URL with no whitespace/malformed host.
- Wired the runtime endpoint contract into `.github/workflows/device-integration.yml` before Flutter/emulator execution.
- This increases runtime confidence without coupling the test to UI-localized strings; the device still exercises the same HTTPS API surface and token lifecycle used by the application.

Validation observed in this environment:
- `npm run check`: PASS
- `npm run test:fast`: 83/83 PASS
- `npm run test:contract`: 40/40 PASS
- `npm run test:product`: 9/9 PASS
- `npm run test:failure-injection`: 2/2 PASS
- `npm run test:provider`: 3/3 PASS
- Android runtime endpoint contract: PASS with HTTPS input; fail-closed behavior verified without an endpoint.

Environment-limited gates that remain intentionally unclaimed:
- Flutter analyzer/test and Android emulator execution require Flutter/Android SDK in CI.
- Real staging S3/PSP/notification tests require external credentials and deployed endpoints.
- DR restore requires disposable PostgreSQL infrastructure.
## Wave 8 — Staging/Production release separation — 2026-08-29

Status: IMPLEMENTED

- Extracted staging integration, operational, DR, and Android certification into reusable `.github/workflows/staging-certification.yml`.
- Production release now depends on the reusable staging certification job via `needs: staging-certification`.
- Production job no longer consumes staging database, S3, metrics, or API secrets.
- Staging S3 certification now supports an explicit HTTPS-only mode through `S3_REQUIRE_HTTPS=1`.
- Added release-hardening and device-certification regression contracts for the new workflow boundary.

Validation observed in this environment:
- Release/device/env targeted contracts: 19/19 PASS.
- YAML parsed successfully with PyYAML (syntax structure check; GitHub-specific semantics still require Actions runner validation).

Next execution target:
1. Run the reusable staging certification in GitHub Actions with real staging credentials.
2. Capture real PSP/S3/notification/DR evidence.
3. Certify Android emulator runtime against staging.
4. Add external observability sink/alerting after the staging gate is proven.


## Wave 9 — Certification evidence isolation
Status: IMPLEMENTED

- Reusable staging workflow now exposes a machine-readable `certification_status` output.
- Staging owns DR restore evidence and uploads it from the correct runner.
- Production release is explicitly gated on `certification_status == PASS`.
- Removed production references to staging-runner DR evidence.

## Wave 9 execution update — 2026-08-29
Status: IMPLEMENTED

- Found and fixed a stale release-evidence contract: DR evidence is owned by the reusable staging certification workflow, not the production runner.
- Staging certification now exposes an explicit `certification_status=PASS` output through `workflow_call`.
- Production release is fail-closed on that certification output before any production build/signing step.
- Staging uploads the DR restore evidence from the runner that actually performed the drill.
- Removed the invalid production artifact upload that referenced a non-existent DR workspace.
- Added regression coverage for evidence ownership and certification gating.

Validation observed:
- Release/device/evidence targeted contracts: 18/18 PASS.
- Backend fast suite: 85/85 PASS.
- Backend contract suite: 40/40 PASS.
- YAML parsing: PASS for staging and production workflows.

Remaining external certification gates:
- Real deployed staging S3/PSP/notification integrations.
- Real PostgreSQL DR restore against disposable infrastructure.
- Android emulator/device execution.
- External metrics/logging/tracing and alerting.


## Wave 11 — Observability & Alerting
Status: COMPLETE (2026-08-29)

Implemented:
- W3C traceparent ingress validation and response propagation.
- Structured `traceId`/`service` fields for error events.
- Optional HTTPS alert webhook with token auth, cooldown, and bounded timeout.
- Alert logic covered by runtime tests and integrated into fast checks.

Still external / blocked in this environment:
- Vendor-backed OpenTelemetry collector/traces.
- Production alert destination credentials and live delivery evidence.

## Wave 12 — CI-backed isolated DR verification
Status: IMPLEMENTED

- Added `.github/workflows/dr-restore.yml` with two disposable PostgreSQL 16 services.
- Source database is initialized via the real migration/seed path before `dr-restore-drill.sh` runs.
- Restore target is a separate database service; archive verification, restore, required-table checks, and live SQL query remain mandatory.
- DR evidence is uploaded as a workflow artifact.
- `dr-restore-drill.sh` now fails closed if source and drill URLs are identical, preventing accidental restoration over the source target.

Environment-limited validation in this workspace:
- Workflow structure and contract assertions can be validated locally.
- Actual PostgreSQL service execution requires a GitHub Actions/Docker runner.
