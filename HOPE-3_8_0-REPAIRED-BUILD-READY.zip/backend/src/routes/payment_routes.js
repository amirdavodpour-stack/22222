export function createPaymentRoutes({
  authUser, readBody, readRawBody, sendJson, HttpError, config, db, repo, getJob,
  enforceJobState, readIdempotencyKey, requireFields, enumField, paymentView, relatedJob, withTransaction, createAudit,
  calculatePaymentBreakdown, fundingJournal, releaseJournal, payoutJournal, refundJournal,
  processPaymentCreateHoldNow, processPaymentReleaseNow, processPaymentRefundNow,
  notifyUser, NOTIFICATION_TYPES, logEvent, now, crypto,
}) {
  return async function paymentRoutes(req, res, parts) {
  if (req.method === 'POST' && parts[1] === 'webhook' && parts.length === 2) {
    if (!config.paymentWebhookSecret) throw new HttpError(503, 'PAYMENT_WEBHOOK_NOT_CONFIGURED', 'Payment webhook is not configured');
    const raw = await readRawBody(req);
    const signature = String(req.headers['x-hope-signature'] || '').trim();
    const expected = `sha256=${crypto.createHmac('sha256', config.paymentWebhookSecret).update(raw).digest('hex')}`;
    const providedBuf = Buffer.from(signature); const expectedBuf = Buffer.from(expected);
    if (!signature || providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) throw new HttpError(401, 'INVALID_WEBHOOK_SIGNATURE', 'Invalid payment webhook signature');
    let body; try { body = JSON.parse(raw.toString('utf8')); } catch { throw new HttpError(400, 'INVALID_JSON', 'Invalid JSON body'); }
    requireFields(body, ['eventId','eventType','paymentId']);
    const eventType = enumField(body.eventType, new Set(['PAYMENT_HELD','PAYMENT_RELEASED','PAYMENT_REFUNDED']), 'eventType');
    const result = process.env.DATABASE_URL
      ? await repo.applyPaymentWebhookAtomic({ eventId:String(body.eventId), eventType, paymentId:String(body.paymentId), providerRef:String(body.providerRef || ''), payload:body })
      : await withTransaction(async () => {
          const duplicate = db.collection.paymentWebhooks.find((x) => x.eventId === String(body.eventId));
          if (duplicate) return {processed:true,duplicate:true,paymentId:duplicate.paymentId};
          db.insert('paymentWebhooks',{id:db.id(),eventId:String(body.eventId),eventType,paymentId:String(body.paymentId),providerRef:String(body.providerRef || ''),payload:body,processedAt:now(),createdAt:now()});
          const payment = db.collection.payments.find((x)=>x.id===String(body.paymentId));
          if (!payment) return {processed:true,duplicate:false,paymentId:null};
          if (eventType==='PAYMENT_HELD' && payment.status==='HOLD_PENDING') { payment.status='HELD'; if(body.providerRef) payment.providerRef=String(body.providerRef); db.touch('payments'); }
          if (eventType==='PAYMENT_RELEASED' && payment.status==='RELEASE_PENDING') { payment.status='RELEASED'; const job=db.collection.jobs.find((x)=>x.id===payment.jobId); if(job){job.status='SETTLED';job.updatedAt=now();db.touch('jobs');} const b={baseAmount:payment.baseAmount||payment.amount,employerFee:payment.employerFee||0,workerFee:payment.workerFee||0,platformFee:payment.platformFee||0,employerCharge:payment.employerCharge||payment.amount,providerPayout:payment.providerPayout||payment.amount,currency:payment.currency||config.paymentCurrency}; for(const journal of [releaseJournal(b),payoutJournal(b)]){const jid=db.id();for(const e of journal)db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_WEBHOOK',referenceId:payment.id,account:e.account,debit:e.debit,credit:e.credit,currency:b.currency,createdAt:now()});} db.insert('settlements',{id:db.id(),paymentId:payment.id,providerRef:String(body.providerRef||payment.providerRef),amount:b.providerPayout,currency:b.currency,status:'RELEASED',createdAt:now(),updatedAt:now()}); db.touch('payments','settlements'); }
          if (eventType==='PAYMENT_REFUNDED' && payment.status==='REFUND_PENDING') { payment.status='REFUNDED'; db.touch('payments'); }
          return {processed:true,duplicate:false,paymentId:payment.id};
        });
    return sendJson(res, 200, result);
  }
  if (req.method === 'GET' && parts[1] === 'jobs' && parts[2]) {
    const me = await authUser(req); const job = await getJob(parts[2]); if (!job) throw new HttpError(404, 'JOB_NOT_FOUND', 'Job not found');
    if (!relatedJob(me.id, job)) throw new HttpError(403, 'FORBIDDEN', 'You are not a participant in this job');
    const payment = process.env.DATABASE_URL ? await repo.findPaymentByJob(job.id) : db.collection.payments.find((p) => p.jobId === job.id); return sendJson(res, 200, await paymentView(payment, job));
  }
  if (req.method === 'GET' && parts[1] === 'financials' && parts[2]) {
    const me = await authUser(req); const job = await getJob(parts[2]); if (!job) throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
    if (!relatedJob(me.id, job) && me.role !== 'ADMIN') throw new HttpError(403,'FORBIDDEN','You are not a participant in this job');
    const payment = process.env.DATABASE_URL ? await repo.findPaymentByJob(job.id) : db.collection.payments.find((p)=>p.jobId===job.id);
    const ledger = payment && process.env.DATABASE_URL ? await repo.listLedgerEntriesForPayment(payment.id) : (payment ? db.collection.ledgerEntries.filter((e)=>e.referenceId===payment.id) : []);
    return sendJson(res,200,{payment:payment?await paymentView(payment,job):await paymentView(null,job),ledger});
  }
  if (req.method === 'POST' && parts[1] === 'fund' && parts[2]) {
    const me = await authUser(req); const body = await readBody(req); const job = await getJob(parts[2]); if (!job) throw new HttpError(404, 'JOB_NOT_FOUND', 'Job not found');
    if (job.ownerId !== me.id) throw new HttpError(403, 'FORBIDDEN', 'Only the owner can fund a job');
    // Check for an already-completed fund (repeat request / retried idempotency
    // key) BEFORE the state guard: by the time a retry arrives the job is no
    // longer PUBLISHED/ASSIGNED (it's already FUNDED), so enforceJobState would
    // otherwise reject the retry with 409 instead of returning the original
    // payment, defeating the point of the idempotency key.
    const headerIdempotencyKey = readIdempotencyKey(req, config.maxIdempotencyKeyLength);
    const bodyIdempotencyKey = String(body?.idempotencyKey || '').trim();
    if (bodyIdempotencyKey && bodyIdempotencyKey.length > config.maxIdempotencyKeyLength) throw new HttpError(400, 'INVALID_IDEMPOTENCY_KEY', 'Idempotency-Key is too long');
    if (bodyIdempotencyKey && !/^[A-Za-z0-9._~:-]+$/.test(bodyIdempotencyKey)) throw new HttpError(400, 'INVALID_IDEMPOTENCY_KEY', 'Idempotency-Key contains unsupported characters');
    if (headerIdempotencyKey && bodyIdempotencyKey && headerIdempotencyKey !== bodyIdempotencyKey) throw new HttpError(400, 'INVALID_IDEMPOTENCY_KEY', 'Header and body idempotency keys must match');
    const idempotencyKey = headerIdempotencyKey || bodyIdempotencyKey;
    // PERF: previously fetched the same payment row twice in a row (once as
    // `existing` to decide whether to short-circuit, once as `existingPayment`
    // a few lines later for the enforceJobState check) with nothing in
    // between that could change the result. One fetch now serves both: by
    // the time the DB-mode branch below falls through without returning, the
    // only payment state left standing is HOLD_FAILED (every other status
    // either returns or throws), which is exactly what enforceJobState needs.
    let existing;
    if (process.env.DATABASE_URL) {
      existing = await repo.findPaymentByJob(job.id);
      if (existing) {
        if (idempotencyKey && existing.idempotencyKey && existing.idempotencyKey !== idempotencyKey) throw new HttpError(409, 'PAYMENT_ALREADY_EXISTS', 'A payment already exists for this job');
        if (existing.status === 'HELD' || existing.status === 'RELEASE_PENDING' || existing.status === 'RELEASED') return sendJson(res,200,await paymentView(existing,job));
        if (existing.status === 'HOLD_PENDING') return sendJson(res,202,{...(await paymentView(existing,job)), settlement:{status:'PENDING',outboxEventId:null}});
        if (existing.status !== 'HOLD_FAILED') throw new HttpError(409,'INVALID_PAYMENT_STATE','Payment cannot be funded from its current state');
      }
    } else {
      existing = db.collection.payments.find((p)=>p.jobId===job.id);
      if(existing) {
        if (idempotencyKey && existing.idempotencyKey && existing.idempotencyKey !== idempotencyKey) {
          throw new HttpError(409, 'PAYMENT_ALREADY_EXISTS', 'A payment already exists for this job');
        }
        if (existing.status === 'HELD' || existing.status === 'RELEASE_PENDING' || existing.status === 'RELEASED') {
          return sendJson(res,200,await paymentView(existing,job));
        }
        if (existing.status === 'HOLD_PENDING') {
          return sendJson(res,202,{...(await paymentView(existing,job)),settlement:{status:'PENDING',outboxEventId:null}});
        }
        if (existing.status !== 'HOLD_FAILED') {
          throw new HttpError(409,'INVALID_PAYMENT_STATE','Payment cannot be funded from its current state');
        }
      }
      if(idempotencyKey){const prior=db.collection.payments.find((p)=>p.payerId===me.id&&p.idempotencyKey===idempotencyKey); if(prior) return sendJson(res,200,await paymentView(prior,job));}
    }
    enforceJobState(job, existing?.status === 'HOLD_FAILED' ? ['FUNDED'] : ['PUBLISHED', 'ASSIGNED']);
    let providerId = job.providerId;
    let chosenOfferId = null;
    if (!providerId) {
      const chosen = process.env.DATABASE_URL ? (await repo.listOffersForJob(job.id)).filter((o)=>o.status==='PENDING').sort((a,b)=>a.price-b.price)[0] : db.collection.offers.filter((o) => o.jobId === job.id && o.status === 'PENDING').sort((a, b) => a.price - b.price)[0];
      if (!chosen) throw new HttpError(409, 'PROVIDER_REQUIRED', 'Accept an offer before funding the job');
      chosenOfferId = chosen.id; providerId = chosen.providerId;
    }
    if (!providerId) throw new HttpError(409, 'PROVIDER_REQUIRED', 'A provider is required before funding');
    const amount = Number(job.kind === 'JOB' ? (job.monthlySalary || job.budgetMax || job.budgetMin) : (job.budgetMax || job.budgetMin)); if (!Number.isFinite(amount) || amount <= 0) throw new HttpError(400, 'INVALID_AMOUNT', 'Job budget is invalid');
    const breakdown = calculatePaymentBreakdown(job.kind || (job.jobType === 'FIXED' ? 'MISSION' : 'JOB'), amount);
    const createdAt = now();
    const paymentId = db.id();
    let funded;
    try {
      funded = process.env.DATABASE_URL ? await repo.fundJobAtomic({ jobId:job.id, payerId:me.id, payeeId:providerId, offerId: chosenOfferId, amount, id:paymentId, idempotencyKey, createdAt, breakdown }) : await withTransaction(async () => {
      // File-mode development fallback remains synchronous; production is PostgreSQL + outbox.
      const created = db.insert('payments', { id: paymentId, jobId: job.id, payerId: me.id, payeeId: providerId, amount, status: 'HELD', providerRef: `LOCAL-${paymentId}`, idempotencyKey, baseAmount:breakdown.baseAmount, employerFee:breakdown.employerFee, workerFee:breakdown.workerFee, platformFee:breakdown.platformFee, employerCharge:breakdown.employerCharge, providerPayout:breakdown.providerPayout, feePolicyVersion:breakdown.policyVersion, currency:breakdown.currency, createdAt, updatedAt: createdAt });
      const jid=db.id(); for(const e of fundingJournal(breakdown)) db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_FUND',referenceId:paymentId,account:e.account,debit:e.debit,credit:e.credit,currency:breakdown.currency,createdAt});
      job.status = 'FUNDED'; job.updatedAt = createdAt; db.touch('jobs'); return { payment:created, job };
      });
    } catch (error) {
      if (error?.code === 'PAYMENT_ALREADY_EXISTS') throw new HttpError(409, 'PAYMENT_ALREADY_EXISTS', 'A payment already exists for this job');
      if (error?.code === 'IDEMPOTENCY_CONFLICT') throw new HttpError(409, 'IDEMPOTENCY_CONFLICT', 'Idempotency key was already used for different payment parameters');
      if (error?.code === 'INVALID_OFFER_STATE') throw new HttpError(409, 'INVALID_OFFER_STATE', 'The selected offer is no longer available');
      if (error?.code === 'INVALID_STATE') throw new HttpError(409, 'INVALID_STATE', 'Job state changed while funding');
      throw error;
    }
    if (!funded) throw new HttpError(404, 'JOB_NOT_FOUND', 'Job not found');
    const payment = funded.payment;
    const finalJob = funded.job;
    if (process.env.DATABASE_URL) {
      try { await processPaymentCreateHoldNow(); } catch (error) { logEvent({ level:'warn', action:'PAYMENT_CREATE_HOLD_WORKER_TRIGGER_FAILED', paymentId:payment.id, error:error.message }); }
      const refreshed = await repo.findPaymentByJob(job.id);
      const refreshedJob = await repo.findJobById(job.id);
      if (refreshed?.status === 'HELD') { await notifyUser({userId:providerId,type:NOTIFICATION_TYPES.PAYMENT_UPDATE,title:'پرداخت با موفقیت انجام شد',body:`پرداخت مرتبط با «${job.title}» با موفقیت در حالت نگهداری قرار گرفت.`,data:{jobId:job.id,paymentId:refreshed.id,status:refreshed.status},dedupeKey:`payment:${refreshed.id}:HELD`,channels:['IN_APP','PUSH']}); return sendJson(res, funded.created ? 201 : 200, await paymentView(refreshed, refreshedJob)); }
      return sendJson(res, funded.created ? 202 : 202, { ...(await paymentView(refreshed || payment, refreshedJob || finalJob)), settlement:{status:'PENDING',outboxEventId:funded.outboxEvent?.id || null} });
    }
    await notifyUser({userId:providerId,type:NOTIFICATION_TYPES.PAYMENT_UPDATE,title:'پرداخت ماموریت ثبت شد',body:`پرداخت مربوط به «${job.title}» ثبت شد.`,data:{jobId:job.id,paymentId:payment.id,status:payment.status},dedupeKey:`payment:${payment.id}:HELD`,channels:['IN_APP','PUSH']});
    await createAudit('PAYMENT_FUND', me.id, 'payment', payment.id, { jobId: job.id });
    return sendJson(res, 201, await paymentView(payment, finalJob));
  }
  if (req.method === 'POST' && parts[1] === 'refund' && parts[2]) {
    const me=await authUser(req); const body=await readBody(req); const job=await getJob(parts[2]); if(!job)throw new HttpError(404,'JOB_NOT_FOUND','Job not found');
    if(job.ownerId!==me.id)throw new HttpError(403,'FORBIDDEN','Only the owner can refund payment');
    const payment=process.env.DATABASE_URL?await repo.findPaymentByJob(job.id):db.collection.payments.find((p)=>p.jobId===job.id); if(!payment)throw new HttpError(409,'PAYMENT_REQUIRED','No payment exists for this job');
    const idempotencyKey=readIdempotencyKey(req, config.maxIdempotencyKeyLength); const createdAt=now(); const refundId=db.id();
    let created;
    try {
      created=process.env.DATABASE_URL?await repo.createRefundAtomic({jobId:job.id,paymentId:payment.id,ownerId:me.id,amount:payment.amount,id:refundId,idempotencyKey,createdAt}):await withTransaction(async()=>{
        if(payment.status!=='HELD') { const e=new Error('INVALID_PAYMENT_STATE');e.code='INVALID_PAYMENT_STATE';throw e; }
        if(idempotencyKey){const prior=db.collection.refunds.find((r)=>r.paymentId===payment.id&&r.idempotencyKey===idempotencyKey);if(prior)return {refund:prior,payment};}
        const refund=db.insert('refunds',{id:refundId,paymentId:payment.id,amount:payment.amount,status:'REFUNDED',providerRef:`LOCAL-REF-${refundId}`,idempotencyKey,createdAt,updatedAt:createdAt}); payment.status='REFUNDED'; payment.updatedAt=createdAt; job.status=job.providerId?'ASSIGNED':'PUBLISHED'; job.updatedAt=createdAt; const b={baseAmount:payment.baseAmount||payment.amount,employerFee:payment.employerFee||0,workerFee:payment.workerFee||0,platformFee:payment.platformFee||0,employerCharge:payment.employerCharge||payment.amount,providerPayout:payment.providerPayout||payment.amount,currency:payment.currency||config.paymentCurrency}; const jid=db.id();for(const e of refundJournal(b))db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_REFUND',referenceId:payment.id,account:e.account,debit:e.debit,credit:e.credit,currency:b.currency,createdAt});db.touch('payments','refunds','jobs');return {refund,payment};
      });
    } catch(e){ if(e.code==='INVALID_PAYMENT_STATE')throw new HttpError(409,'INVALID_PAYMENT_STATE','Payment cannot be refunded from its current state'); if(e.code==='PARTIAL_REFUND_UNSUPPORTED')throw new HttpError(400,'PARTIAL_REFUND_UNSUPPORTED','Only full refunds are currently supported'); throw e; }
    if(process.env.DATABASE_URL){ try{await processPaymentRefundNow();}catch(error){logEvent({level:'warn',action:'PAYMENT_REFUND_WORKER_TRIGGER_FAILED',paymentId:payment.id,error:error.message});} const refreshed=await repo.findPaymentByJob(job.id); return sendJson(res,created.refund.status==='PENDING'?202:200,{...(await paymentView(refreshed||created.payment,await repo.findJobById(job.id))),refund:created.refund}); }
    await createAudit('PAYMENT_REFUND',me.id,'payment',payment.id,{jobId:job.id}); return sendJson(res,200,{...(await paymentView(created.payment,job)),refund:created.refund});
  }
  if (req.method === 'POST' && parts[1] === 'release' && parts[2]) {
    const me = await authUser(req); const job = await getJob(parts[2]); if (!job) throw new HttpError(404, 'JOB_NOT_FOUND', 'Job not found');
    if (job.ownerId !== me.id) throw new HttpError(403, 'FORBIDDEN', 'Only the owner can release payment');
    enforceJobState(job, ['COMPLETED']);
    const payment = process.env.DATABASE_URL ? await repo.findPaymentByJob(job.id) : db.collection.payments.find((p) => p.jobId === job.id); if (!payment || payment.status !== 'RELEASE_PENDING') throw new HttpError(409, 'INVALID_PAYMENT_STATE', 'Payment is not ready for release');
    if (process.env.DATABASE_URL) {
      const event = await repo.enqueuePaymentRelease({ jobId:job.id, ownerId:me.id, paymentId:payment.id, dedupeKey:`PAYMENT_RELEASE:${payment.id}` });
      try { await processPaymentReleaseNow(); } catch (error) { logEvent({ level:'warn', action:'PAYMENT_RELEASE_WORKER_TRIGGER_FAILED', paymentId:payment.id, error:error.message }); }
      const refreshed = await repo.findPaymentByJob(job.id);
      const finalJob = await repo.findJobById(job.id);
      if (refreshed?.status === 'RELEASED') { await notifyUser({userId:refreshed.payeeId,type:NOTIFICATION_TYPES.PAYMENT_UPDATE,title:'پرداخت تسویه شد',body:`پرداخت مربوط به «${job.title}» تسویه شد.`,data:{jobId:job.id,paymentId:refreshed.id,status:refreshed.status},dedupeKey:`payment:${refreshed.id}:RELEASED`,channels:['IN_APP','PUSH','EMAIL']}); return sendJson(res, 200, await paymentView(refreshed, finalJob)); }
      return sendJson(res, 202, { ...(await paymentView(refreshed, finalJob)), settlement: { status:'PENDING', outboxEventId:event?.id || null } });
    }
    await withTransaction(async () => {
      payment.status = 'RELEASED'; payment.updatedAt = now(); job.status = 'SETTLED'; job.updatedAt = now(); const b={baseAmount:payment.baseAmount||payment.amount,employerFee:payment.employerFee||0,workerFee:payment.workerFee||0,platformFee:payment.platformFee||0,employerCharge:payment.employerCharge||payment.amount,providerPayout:payment.providerPayout||payment.amount,currency:payment.currency||config.paymentCurrency}; for(const journal of [releaseJournal(b),payoutJournal(b)]){const jid=db.id();for(const e of journal)db.insert('ledgerEntries',{id:db.id(),journalId:jid,referenceType:'PAYMENT_RELEASE',referenceId:payment.id,account:e.account,debit:e.debit,credit:e.credit,currency:b.currency,createdAt:now()});} db.insert('settlements',{id:db.id(),paymentId:payment.id,providerRef:payment.providerRef,amount:b.providerPayout,currency:b.currency,status:'RELEASED',createdAt:now(),updatedAt:now()}); db.touch('payments', 'jobs', 'ledgerEntries', 'settlements');
      await createAudit('PAYMENT_RELEASE', me.id, 'payment', payment.id, { jobId: job.id });
    });
    await notifyUser({userId:payment.payeeId,type:NOTIFICATION_TYPES.PAYMENT_UPDATE,title:'پرداخت تسویه شد',body:`پرداخت مربوط به «${job.title}» تسویه شد.`,data:{jobId:job.id,paymentId:payment.id,status:payment.status},dedupeKey:`payment:${payment.id}:RELEASED`,channels:['IN_APP','PUSH','EMAIL']});
    return sendJson(res, 200, await paymentView(payment, job));
  }
  throw new HttpError(404, 'NOT_FOUND', 'Payment route not found');
  };
}
