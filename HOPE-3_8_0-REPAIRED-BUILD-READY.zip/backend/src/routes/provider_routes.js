export function createProviderRoutes({ authUser, getProvider, publicUser, db, repo, sendJson, HttpError, now, readBody, textField, enumField, createAudit, notifyUser }) {
  return async function providerRoutes(req, res, parts) {
    if (req.method === 'GET' && parts[2] === 'reputation' && parts[1]) {
      const summary = process.env.DATABASE_URL ? await repo.getReputationSummary(parts[1]) : (() => {
        const rows = db.collection.jobReviews.filter((r) => r.revieweeId === parts[1]);
        const total = rows.reduce((sum,r) => sum + Number(r.rating || 0), 0);
        const distribution = {5:0,4:0,3:0,2:0,1:0}; for (const r of rows) distribution[Number(r.rating)] = (distribution[Number(r.rating)] || 0) + 1;
        return {count:rows.length,average:rows.length ? Number((total/rows.length).toFixed(2)) : 0,distribution};
      })();
      return sendJson(res, 200, summary);
    }
    if (parts[2] === 'verification') {
      const user = await authUser(req);
      if (req.method === 'GET') {
        const latest = process.env.DATABASE_URL ? await repo.getLatestProviderVerification(user.id) : db.collection.providerVerifications.filter(v => v.providerUserId === user.id).sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt)))[0] || null;
        return sendJson(res, 200, latest);
      }
      if (req.method === 'POST') {
        const body = await readBody(req);
        const documentType = enumField(body?.documentType, new Set(['IDENTITY','BUSINESS','PROFESSIONAL']), 'documentType');
        const evidenceUri = textField(body?.evidenceUri, 'evidenceUri', {min: 10, max: 2048, required: true});
        if (!/^storage:\/\/[A-Za-z0-9._~:/%-]+$/.test(evidenceUri)) throw new HttpError(400,'INVALID_STORAGE_REFERENCE','Verification evidence must use a storage:// reference');
        if (evidenceUri.includes('..') || evidenceUri.includes('\\')) throw new HttpError(400,'INVALID_STORAGE_REFERENCE','Verification evidence reference is invalid');
        const item={id:db.id(),providerUserId:user.id,documentType,evidenceUri,status:'PENDING',reviewNote:'',reviewedBy:null,reviewedAt:null,createdAt:now(),updatedAt:now()};
        let created;
        try { created=process.env.DATABASE_URL ? await repo.createProviderVerificationAtomic(item) : (()=>{ const existing=db.collection.providerVerifications.find(v=>v.providerUserId===user.id&&v.status==='PENDING'); if(existing) throw Object.assign(new Error('VERIFICATION_ALREADY_PENDING'),{code:'VERIFICATION_ALREADY_PENDING'}); if(!db.collection.uploads.some(u=>u.storageKey===evidenceUri.slice('storage://'.length)&&u.uploadedBy===user.id)) throw Object.assign(new Error('INVALID_STORAGE_REFERENCE'),{code:'INVALID_STORAGE_REFERENCE'}); const v=db.insert('providerVerifications',item); const provider=db.collection.providers.find(p=>p.userId===user.id); if(provider){provider.verificationStatus='PENDING';provider.updatedAt=now();db.touch('providers');} return v; })(); }
        catch(error){ if(error?.code==='VERIFICATION_ALREADY_PENDING') throw new HttpError(409,'VERIFICATION_ALREADY_PENDING','A verification request is already pending'); if(error?.code==='INVALID_STORAGE_REFERENCE') throw new HttpError(403,'INVALID_STORAGE_REFERENCE','Verification evidence does not belong to this user'); throw error; }
        if(!process.env.DATABASE_URL) await db.save();
        await createAudit('PROVIDER_VERIFICATION_SUBMIT',user.id,'provider_verification',created.id,{documentType});
        return sendJson(res,201,{id:created.id,status:created.status,documentType:created.documentType});
      }
    }
    if (req.method !== 'GET' || parts[1] !== 'me') throw new HttpError(404, 'NOT_FOUND', 'Provider route not found');
    const user = await authUser(req);
    let provider = await getProvider(user.id);
    if (!provider) {
      const draft={ id: db.id(), userId: user.id, providerType:'INDIVIDUAL', capacity:'OPEN', verificationStatus:'UNVERIFIED', createdAt:now(), updatedAt:now() };
      provider = process.env.DATABASE_URL ? await repo.upsertProvider(draft) : db.insert('providers', draft);
    }
    return sendJson(res, 200, { ...provider, user: publicUser(user) });
  };
}
