export function createAuthRoutes({
  authUser, authUserView, getUserByEmail, issueSession, deliverPasswordReset, findUser,
  readBody, sendJson, HttpError, requireFields, db, repo, config, now, hashPassword,
  verifyPassword, randomToken, sha256, signAccessToken, withTransaction, createAudit, DUMMY_PASSWORD_HASH,
  logEvent,
}) {
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  return async function authRoutes(req, res, parts) {
    const route = parts.slice(1).join('/');
    if (req.method === 'POST' && route === 'register') {
      const body = await readBody(req);
      requireFields(body, ['email', 'password', 'displayName']);
      const email = String(body.email).trim().toLowerCase();
      if (email.length > 254 || !emailRe.test(email)) throw new HttpError(400, 'INVALID_EMAIL', 'Email is invalid');
      if (String(body.password).length < 8) throw new HttpError(400, 'WEAK_PASSWORD', 'Password must be at least 8 characters');
      if (await getUserByEmail(email)) throw new HttpError(409, 'EMAIL_IN_USE', 'An account with this email already exists');
      const userDraft = { id: db.id(), email, passwordHash: await hashPassword(String(body.password)), displayName: String(body.displayName).trim(), role: 'USER', status: 'ACTIVE', sessionVersion: 0, createdAt: now() };
      const providerDraft = { id: db.id(), userId: userDraft.id, providerType: 'INDIVIDUAL', capacity: 'OPEN', verificationStatus: 'UNVERIFIED', createdAt: now(), updatedAt: now() };
      let user;
      try {
        user = process.env.DATABASE_URL ? await repo.createUserWithProvider(userDraft, providerDraft) : db.insert('users', userDraft);
      } catch (error) {
        if (error?.code === '23505' || error?.constraint === 'users_email_key') throw new HttpError(409, 'EMAIL_IN_USE', 'An account with this email already exists');
        throw error;
      }
      if (!process.env.DATABASE_URL) db.insert('providers', providerDraft);
      const session = await issueSession(user);
      await createAudit('AUTH_REGISTER', user.id, 'user', user.id);
      return sendJson(res, 201, { ...session, user: authUserView(user) });
    }

    if (req.method === 'POST' && route === 'login') {
      const body = await readBody(req);
      requireFields(body, ['email', 'password']);
      const email = String(body.email).trim().toLowerCase();
      if (email.length > 254 || !emailRe.test(email)) throw new HttpError(400, 'INVALID_EMAIL', 'Email is invalid');
      const user = await getUserByEmail(email);
      // Always perform the expensive password verification step, including for unknown users,
      // to reduce account-enumeration through response-time differences.
      const passwordOk = await verifyPassword(String(body.password), user?.passwordHash || DUMMY_PASSWORD_HASH);
      if (!user || user.status !== 'ACTIVE' || !passwordOk) throw new HttpError(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect');
      const session = await issueSession(user);
      await createAudit('AUTH_LOGIN', user.id, 'user', user.id);
      return sendJson(res, 200, { ...session, user: authUserView(user) });
    }

    if (req.method === 'POST' && route === 'refresh') {
      const body = await readBody(req);
      requireFields(body, ['refreshToken']);
      const presentedHash = sha256(String(body.refreshToken));
      if (process.env.DATABASE_URL) {
        const refresh = randomToken(48);
        const nextToken = { id:db.id(), tokenHash:sha256(refresh), familyId:db.id(), expiresAt:new Date(Date.now()+config.refreshTtlSeconds*1000).toISOString(), createdAt:now() };
        const existing = await repo.findRefreshTokenByHash(presentedHash);
        if (!existing || new Date(existing.expiresAt).getTime() <= Date.now()) throw new HttpError(401,'INVALID_REFRESH_TOKEN','Refresh token is invalid or expired');
        nextToken.familyId = existing.familyId;
        const rotated = await repo.rotateRefreshToken(presentedHash,nextToken,existing.familyId);
        if (rotated.kind === 'reuse') throw new HttpError(401,'REFRESH_REUSE_DETECTED','Refresh token reuse detected; session family revoked');
        if (rotated.kind !== 'ok' || rotated.user.status !== 'ACTIVE') throw new HttpError(401,'INVALID_REFRESH_TOKEN','Refresh token is invalid');
        const issued = { accessToken:signAccessToken({sub:rotated.user.id,role:rotated.user.role,sv:Number(rotated.user.sessionVersion || 0)},config.accessSecret,config.accessTtlSeconds,{issuer:config.accessIssuer,audience:config.accessAudience}), refreshToken:refresh };
        return sendJson(res,200,{...issued,user:authUserView(rotated.user)});
      }
      const item = db.collection.refreshTokens.find((t) => t.tokenHash === presentedHash);
      if (!item || new Date(item.expiresAt).getTime() <= Date.now()) throw new HttpError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token is invalid or expired');
      if (item.revokedAt) {
        for (const token of db.collection.refreshTokens.filter((t) => t.familyId === item.familyId && !t.revokedAt)) token.revokedAt = now();
        db.touch('refreshTokens'); await db.save();
        throw new HttpError(401, 'REFRESH_REUSE_DETECTED', 'Refresh token reuse detected; session family revoked');
      }
      const next = await withTransaction(async () => {
        const current = db.collection.refreshTokens.find((t) => t.id === item.id);
        if (!current || current.revokedAt) throw new HttpError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token is invalid');
        const user = findUser(current.userId);
        if (!user || user.status !== 'ACTIVE') throw new HttpError(401, 'INVALID_REFRESH_TOKEN', 'Refresh token is invalid');
        const issued = await issueSession(user, current.familyId); current.revokedAt = now(); current.replacedBy = sha256(issued.refreshToken); db.touch('refreshTokens'); return { issued, user };
      });
      return sendJson(res, 200, { ...next.issued, user: authUserView(next.user) });
    }

    if (req.method === 'POST' && route === 'logout') {
      const user = await authUser(req);
      if (process.env.DATABASE_URL) { await repo.revokeUserRefreshTokens(user.id); await repo.bumpUserSessionVersion(user.id); }
      else { user.sessionVersion = Number(user.sessionVersion || 0) + 1; db.touch('users'); for (const token of db.collection.refreshTokens.filter((t) => t.userId === user.id && !t.revokedAt)) token.revokedAt = now(); db.touch('refreshTokens'); db.save(); }
      await createAudit('AUTH_LOGOUT', user.id, 'user', user.id);
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && route === 'password-reset/confirm') {
      const body = await readBody(req);
      requireFields(body, ['token', 'password']);
      if (String(body.password).length < 8) throw new HttpError(400, 'WEAK_PASSWORD', 'Password must be at least 8 characters');
      if (process.env.DATABASE_URL) {
        const candidate = await repo.findResetTokenForUse(sha256(String(body.token)));
        if (!candidate || candidate.user.status !== 'ACTIVE') throw new HttpError(400,'INVALID_RESET_TOKEN','Reset token is invalid or expired');
        const ok = await repo.consumeResetTokenAndChangePassword(candidate.token.id,candidate.user.id,await hashPassword(String(body.password)));
        if (!ok) throw new HttpError(400,'INVALID_RESET_TOKEN','Reset token is invalid or already used');
        await repo.bumpUserSessionVersion(candidate.user.id);
        await createAudit('AUTH_PASSWORD_RESET', candidate.user.id, 'user', candidate.user.id);
        return sendJson(res,200,{ok:true});
      }
      const reset = db.collection.resetTokens.find((t) => t.tokenHash === sha256(String(body.token)) && !t.usedAt && new Date(t.expiresAt).getTime() > Date.now());
      if (!reset) throw new HttpError(400, 'INVALID_RESET_TOKEN', 'Reset token is invalid or expired');
      const user = findUser(reset.userId);
      if (!user || user.status !== 'ACTIVE') throw new HttpError(400, 'INVALID_RESET_TOKEN', 'Reset token is invalid');
      user.passwordHash = await hashPassword(String(body.password)); user.sessionVersion = Number(user.sessionVersion || 0) + 1; reset.usedAt = now();
      for (const token of db.collection.refreshTokens.filter((t) => t.userId === user.id && !t.revokedAt)) token.revokedAt = now();
      db.touch('users', 'refreshTokens', 'resetTokens'); db.save(); await createAudit('AUTH_PASSWORD_RESET', user.id, 'user', user.id);
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'POST' && route === 'password-reset/request') {
      const body = await readBody(req);
      requireFields(body, ['email']);
      const user = await getUserByEmail(String(body.email).trim().toLowerCase());
      const generic = { ok: true, message: 'If the account exists, a reset request has been created.' };
      if (!user) return sendJson(res, 202, generic);
      const token = randomToken(32);
      const resetDraft = { id: db.id(), userId: user.id, tokenHash: sha256(token), familyId:db.id(), expiresAt: new Date(Date.now() + config.resetTokenTtlSeconds * 1000).toISOString(), usedAt: null, createdAt: now() };
      if (process.env.DATABASE_URL) await repo.insertResetToken(resetDraft); else db.insert('resetTokens', resetDraft);
      try {
        await deliverPasswordReset({ user, token });
      } catch (error) {
        if (!process.env.DATABASE_URL) { const created = db.collection.resetTokens.find((t) => t.tokenHash === sha256(token)); if (created) { created.usedAt = now(); db.touch('resetTokens'); } }
        logEvent({ level:'error', action:'PASSWORD_RESET_DELIVERY_FAILED', userId:user.id, message:error.message });
        // Keep the external response generic even when delivery fails so the endpoint does not
        // become an account-enumeration oracle based on status code.
        return sendJson(res, 202, generic);
      }
      logEvent({ level: 'info', action: 'PASSWORD_RESET_REQUESTED', userId: user.id });
      return sendJson(res, 202, config.exposeResetTokenInDevelopment && process.env.NODE_ENV !== 'production' ? { ...generic, resetToken: token } : generic);
    }
    throw new HttpError(404, 'NOT_FOUND', 'Auth route not found');
  };
}
