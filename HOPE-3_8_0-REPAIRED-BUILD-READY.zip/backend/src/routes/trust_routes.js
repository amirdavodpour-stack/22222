export function createTrustRoutes({ authUser, getJob, db, repo, readBody, sendJson, HttpError, textField, enumField, now, createAudit, notifyUser }) {
  return async function trustRoutes(req, res, parts, job) {
    if (parts[2] === 'reviews') {
      if (req.method === 'GET') {
        const viewer = req.headers.authorization ? await authUser(req) : null;
        if (!['PUBLISHED','SETTLED'].includes(job.status) && (!viewer || (job.ownerId !== viewer.id && job.providerId !== viewer.id))) {
          throw new HttpError(404, 'JOB_NOT_FOUND', 'Job not found');
        }
        const reviews = process.env.DATABASE_URL ? await repo.listJobReviews(job.id) : db.collection.jobReviews.filter((r) => r.jobId === job.id).sort((a,b) => String(a.createdAt).localeCompare(String(b.createdAt))).map((r) => ({...r, reviewerName: db.collection.users.find((u) => u.id === r.reviewerId)?.displayName || null}));
        const summary = buildReviewSummary(reviews);
        return sendJson(res, 200, { reviews: reviews.map(({ reviewerId, revieweeId, ...safe }) => ({ ...safe, reviewerName: safe.reviewerName || null })), summary });
      }
      if (req.method === 'POST') {
        const me = await authUser(req);
        if (!['SETTLED'].includes(job.status)) throw new HttpError(409, 'REVIEW_NOT_AVAILABLE', 'Reviews become available after settlement');
        if (![job.ownerId, job.providerId].includes(me.id)) throw new HttpError(403, 'FORBIDDEN', 'Only job participants can review this transaction');
        if (!job.providerId || me.id === job.ownerId && me.id === job.providerId) throw new HttpError(409, 'REVIEW_PARTICIPANT_REQUIRED', 'A second participant is required for a review');
        const reviewerRole = me.id === job.ownerId ? 'OWNER' : 'PROVIDER';
        const revieweeId = me.id === job.ownerId ? job.providerId : job.ownerId;
        const body = await readBody(req);
        const rating = Number(body?.rating);
        if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new HttpError(400, 'INVALID_RATING', 'rating must be an integer from 1 to 5');
        const comment = textField(body?.comment, 'comment', { min: 0, max: 1000 });
        const draft = { id: db.id(), jobId: job.id, reviewerId: me.id, revieweeId, reviewerRole, rating, comment, createdAt: now(), updatedAt: now() };
        let created;
        try {
          created = process.env.DATABASE_URL ? await repo.createJobReview(draft) : (() => {
            if (db.collection.jobReviews.some((r) => r.jobId === job.id && r.reviewerId === me.id)) throw Object.assign(new Error('REVIEW_ALREADY_EXISTS'), { code: 'REVIEW_ALREADY_EXISTS' });
            const r = db.insert('jobReviews', draft); return r;
          })();
        } catch (error) {
          if (error?.code === 'REVIEW_ALREADY_EXISTS' || error?.code === '23505') throw new HttpError(409, 'REVIEW_ALREADY_EXISTS', 'You have already reviewed this transaction');
          throw error;
        }
        if (!process.env.DATABASE_URL) await db.save();
        await createAudit('JOB_REVIEW_CREATE', me.id, 'job_review', created.id, { jobId: job.id, rating });
        await notifyUser({ userId: revieweeId, type: 'JOB_REVIEW_RECEIVED', title: 'بازخورد جدیدی دریافت کردید', body: `برای تراکنش «${job.title}» یک امتیاز جدید ثبت شد.`, data: { jobId: job.id, reviewId: created.id }, dedupeKey: `job-review:${created.id}`, channels: ['IN_APP', 'PUSH', 'EMAIL'] });
        return sendJson(res, 201, { ...created, reviewerId: undefined, revieweeId: undefined });
      }
    }

    if (parts[2] === 'dispute') {
      if (req.method === 'GET') {
        const me = await authUser(req);
        if (job.ownerId !== me.id && job.providerId !== me.id) throw new HttpError(403, 'FORBIDDEN', 'Only participants can view a job dispute');
        const disputes = process.env.DATABASE_URL ? await repo.listJobDisputesForJob(job.id) : db.collection.jobDisputes.filter((d) => d.jobId === job.id).sort((a,b) => String(b.createdAt).localeCompare(String(a.createdAt)));
        return sendJson(res, 200, disputes);
      }
      if (req.method === 'POST') {
        const me = await authUser(req);
        if (![job.ownerId, job.providerId].includes(me.id)) throw new HttpError(403, 'FORBIDDEN', 'Only job participants can open a dispute');
        if (!['IN_PROGRESS', 'DELIVERED', 'UNDER_REVIEW'].includes(job.status)) throw new HttpError(409, 'DISPUTE_NOT_AVAILABLE', 'A dispute can only be opened while a job is in progress or under review');
        const body = await readBody(req);
        const reason = textField(body?.reason, 'reason', { min: 3, max: 120, required: true });
        const details = textField(body?.details, 'details', { min: 0, max: 2000 });
        const againstUserId = me.id === job.ownerId ? job.providerId : job.ownerId;
        const draft = { id: db.id(), jobId: job.id, openedBy: me.id, againstUserId, reason, details, status: 'OPEN', resolutionType: null, resolutionNote: '', resolvedBy: null, resolvedAt: null, createdAt: now(), updatedAt: now() };
        let created;
        try {
          created = process.env.DATABASE_URL ? await repo.openJobDisputeAtomic(draft) : (() => {
            if (db.collection.jobDisputes.some((d) => d.jobId === job.id && ['OPEN','REVIEWING','AWAITING_FINANCIAL_ACTION'].includes(d.status))) throw Object.assign(new Error('ACTIVE_DISPUTE_EXISTS'), { code: 'ACTIVE_DISPUTE_EXISTS' });
            if (job.status === 'DELIVERED') { job.status = 'UNDER_REVIEW'; job.updatedAt = now(); db.touch('jobs'); }
            return db.insert('jobDisputes', draft);
          })();
        } catch (error) {
          if (error?.code === 'ACTIVE_DISPUTE_EXISTS' || error?.code === '23505') throw new HttpError(409, 'ACTIVE_DISPUTE_EXISTS', 'An active dispute already exists for this job');
          throw error;
        }
        if (!process.env.DATABASE_URL) await db.save();
        await createAudit('JOB_DISPUTE_OPEN', me.id, 'job_dispute', created.id, { jobId: job.id, reason });
        await notifyUser({ userId: againstUserId, type: 'JOB_DISPUTE_OPENED', title: 'برای یک تراکنش اختلاف ثبت شد', body: `برای تراکنش «${job.title}» یک اختلاف ثبت شده است.`, data: { jobId: job.id, disputeId: created.id }, dedupeKey: `job-dispute:${created.id}`, channels: ['IN_APP', 'PUSH', 'EMAIL'] });
        return sendJson(res, 201, created);
      }
    }

    if (parts[2] === 'rework') {
      if (req.method === 'GET') {
        const me = await authUser(req);
        if (job.ownerId !== me.id && job.providerId !== me.id) throw new HttpError(403, 'FORBIDDEN', 'Only participants can view rework requests');
        const item = process.env.DATABASE_URL ? await repo.getOpenReworkRequest(job.id) : db.collection.jobReworkRequests.find((r) => r.jobId === job.id && r.status === 'OPEN') || null;
        return sendJson(res, 200, item);
      }
      if (req.method === 'POST') {
        const me = await authUser(req);
        if (me.id !== job.ownerId) throw new HttpError(403, 'FORBIDDEN', 'Only the job owner can request rework');
        if (!['DELIVERED', 'UNDER_REVIEW'].includes(job.status)) throw new HttpError(409, 'REWORK_NOT_AVAILABLE', 'Rework can only be requested after delivery');
        const activeDispute = process.env.DATABASE_URL ? await repo.hasActiveJobDispute(job.id) : db.collection.jobDisputes.some((d) => d.jobId === job.id && ['OPEN','REVIEWING','AWAITING_FINANCIAL_ACTION'].includes(d.status));
        if (activeDispute) throw new HttpError(409, 'ACTIVE_DISPUTE', 'Resolve the active dispute before requesting rework');
        const body = await readBody(req);
        const reason = textField(body?.reason, 'reason', { min: 3, max: 120, required: true });
        const existing = process.env.DATABASE_URL ? await repo.getOpenReworkRequest(job.id) : db.collection.jobReworkRequests.find((r) => r.jobId === job.id && r.status === 'OPEN');
        if (existing) throw new HttpError(409, 'REWORK_ALREADY_OPEN', 'An active rework request already exists for this job');
        if (job.status === 'DELIVERED') {
          if (process.env.DATABASE_URL) await repo.updateJobSimple(job.id, ['DELIVERED'], { status: 'UNDER_REVIEW', updatedAt: now() });
          else { job.status = 'UNDER_REVIEW'; job.updatedAt = now(); db.touch('jobs'); }
        }
        const draft = { id: db.id(), jobId: job.id, requestedBy: me.id, reason, status: 'OPEN', createdAt: now(), updatedAt: now(), completedAt: null };
        const created = process.env.DATABASE_URL ? await repo.createReworkRequest(draft) : db.insert('jobReworkRequests', draft);
        if (!process.env.DATABASE_URL) await db.save();
        await createAudit('JOB_REWORK_REQUEST', me.id, 'job_rework_request', created.id, { jobId: job.id });
        await notifyUser({ userId: job.providerId, type: 'JOB_REWORK_REQUESTED', title: 'اصلاح مجدد درخواست شد', body: `برای تراکنش «${job.title}» نیاز به اصلاح و تحویل مجدد وجود دارد.`, data: { jobId: job.id, reworkId: created.id }, dedupeKey: `job-rework:${created.id}`, channels: ['IN_APP', 'PUSH', 'EMAIL'] });
        return sendJson(res, 201, created);
      }
    }

    if (parts[2] === 'cancel' && req.method === 'POST') {
      const me = await authUser(req);
      if (job.ownerId !== me.id) throw new HttpError(403, 'FORBIDDEN', 'Only the job owner can cancel this opportunity');
      if (!['DRAFT', 'PUBLISHED', 'ASSIGNED'].includes(job.status)) throw new HttpError(409, 'CANCELLATION_REQUIRES_REVIEW', 'Cancellation after funding requires a financial review or dispute');
      const body = await readBody(req);
      const reason = textField(body?.reason, 'reason', { min: 3, max: 240, required: true });
      let updated;
      if (process.env.DATABASE_URL) updated = await repo.updateJobSimple(job.id, [job.status], { status: 'CANCELLED', updatedAt: now() });
      else { job.status = 'CANCELLED'; job.updatedAt = now(); db.touch('jobs'); updated = job; }
      if (!process.env.DATABASE_URL) await db.save();
      await createAudit('JOB_CANCEL', me.id, 'job', job.id, { reason });
      if (job.providerId) await notifyUser({ userId: job.providerId, type: 'MISSION_UPDATE', title: 'تراکنش لغو شد', body: `تراکنش «${job.title}» لغو شد.`, data: { jobId: job.id }, dedupeKey: `job-cancel:${job.id}:${updated.updatedAt}`, channels: ['IN_APP', 'PUSH', 'EMAIL'] });
      return sendJson(res, 200, { id: updated.id, status: updated.status, cancellationReason: reason });
    }
    throw new HttpError(404, 'NOT_FOUND', 'Trust route not found');
  };
}

function buildReviewSummary(reviews) {
  const count = reviews.length;
  const total = reviews.reduce((sum, r) => sum + Number(r.rating || 0), 0);
  const distribution = { 5:0, 4:0, 3:0, 2:0, 1:0 };
  for (const r of reviews) distribution[Number(r.rating)] = (distribution[Number(r.rating)] || 0) + 1;
  return { count, average: count ? Number((total / count).toFixed(2)) : 0, distribution };
}
