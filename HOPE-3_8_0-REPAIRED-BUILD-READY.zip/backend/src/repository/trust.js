import crypto from 'node:crypto';
import { withSqlTransaction } from '../db.js';
import { requirePool } from './context.js';

export async function insertTrustReport(report) {
  const {rows}=await requirePool().query(`INSERT INTO trust_reports(id,reporter_id,entity_type,entity_id,reason,details,status,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[report.id,report.reporterId,report.entityType,report.entityId,report.reason,report.details||'',report.status||'OPEN',report.createdAt,report.updatedAt]);
  const r=rows[0]; return {id:r.id,reporterId:r.reporter_id,entityType:r.entity_type,entityId:r.entity_id,reason:r.reason,details:r.details||'',status:r.status,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at};
}
export async function listTrustReports(status=null) {
  const params=[]; const where=status?(params.push(status),'WHERE r.status=$1'):'';
  const {rows}=await requirePool().query(`SELECT r.*,u.display_name AS reporter_name FROM trust_reports r LEFT JOIN users u ON u.id=r.reporter_id ${where} ORDER BY r.created_at DESC LIMIT 500`,params);
  return rows.map(r=>({id:r.id,reporterId:r.reporter_id,reporterName:r.reporter_name||null,entityType:r.entity_type,entityId:r.entity_id,reason:r.reason,details:r.details||'',status:r.status,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}));
}
export async function updateTrustReportStatus(id,status) {
  const {rows}=await requirePool().query(`UPDATE trust_reports SET status=$2,updated_at=NOW() WHERE id=$1 RETURNING *`,[id,status]);
  const r=rows[0]; return r?{id:r.id,reporterId:r.reporter_id,entityType:r.entity_type,entityId:r.entity_id,reason:r.reason,details:r.details||'',status:r.status,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}:null;
}
export async function listCandidatesForComparison(jobId, applicationIds) {
  const ids=Array.isArray(applicationIds)?applicationIds.slice(0,10):[]; if(!ids.length) return [];
  const {rows}=await requirePool().query(`SELECT a.id,a.resume_text,a.skills,a.status,u.display_name,u.id AS user_id FROM job_applications a JOIN users u ON u.id=a.candidate_id WHERE a.job_id=$1 AND a.id = ANY($2::uuid[]) AND a.status IN ('FORWARDED','INTERVIEW','OFFERED','ACCEPTED')`,[jobId,ids]);
  return rows.map(r=>({id:r.id,candidateId:r.user_id,resumeText:r.resume_text||'',skills:r.skills||'',status:r.status,displayName:r.display_name||'Candidate'}));
}



export async function createJobReview(review) {
  const {rows}=await requirePool().query(`INSERT INTO job_reviews(id,job_id,reviewer_id,reviewee_id,reviewer_role,rating,comment,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,[review.id,review.jobId,review.reviewerId,review.revieweeId,review.reviewerRole,review.rating,review.comment||'',review.createdAt,review.updatedAt]);
  const r=rows[0]; return mapJobReview(r);
}
export async function listJobReviews(jobId) {
  const {rows}=await requirePool().query(`SELECT r.*,u.display_name AS reviewer_name FROM job_reviews r JOIN users u ON u.id=r.reviewer_id WHERE r.job_id=$1 ORDER BY r.created_at ASC`,[jobId]);
  return rows.map(r=>({...mapJobReview(r),reviewerName:r.reviewer_name}));
}
export async function getReputationSummary(userId) {
  const {rows}=await requirePool().query(`SELECT COUNT(*)::int AS count, COALESCE(ROUND(AVG(rating)::numeric,2),0) AS average, COUNT(*) FILTER (WHERE rating=5)::int AS five, COUNT(*) FILTER (WHERE rating=4)::int AS four, COUNT(*) FILTER (WHERE rating=3)::int AS three, COUNT(*) FILTER (WHERE rating=2)::int AS two, COUNT(*) FILTER (WHERE rating=1)::int AS one FROM job_reviews WHERE reviewee_id=$1`,[userId]);
  const r=rows[0]||{}; return {count:Number(r.count||0),average:Number(r.average||0),distribution:{5:Number(r.five||0),4:Number(r.four||0),3:Number(r.three||0),2:Number(r.two||0),1:Number(r.one||0)}};
}
export async function hasActiveJobDispute(jobId) {
  const {rows}=await requirePool().query(`SELECT 1 FROM job_disputes WHERE job_id=$1 AND status IN ('OPEN','REVIEWING','AWAITING_FINANCIAL_ACTION') LIMIT 1`,[jobId]);
  return Boolean(rows[0]);
}
export async function listJobDisputesForJob(jobId) {
  const {rows}=await requirePool().query(`SELECT * FROM job_disputes WHERE job_id=$1 ORDER BY created_at DESC`,[jobId]);
  return rows.map(mapJobDispute);
}
export async function openJobDisputeAtomic(dispute) {
  const client=await requirePool().connect();
  try {
    await client.query('BEGIN');
    const {rows:jobs}=await client.query(`SELECT status,provider_id FROM jobs WHERE id=$1 FOR UPDATE`,[dispute.jobId]);
    const job=jobs[0]; if(!job) { const e=new Error('JOB_NOT_FOUND'); e.code='JOB_NOT_FOUND'; throw e; }
    if(!['IN_PROGRESS','DELIVERED','UNDER_REVIEW'].includes(job.status)) { const e=new Error('DISPUTE_NOT_AVAILABLE'); e.code='DISPUTE_NOT_AVAILABLE'; throw e; }
    const {rows:active}=await client.query(`SELECT id FROM job_disputes WHERE job_id=$1 AND status IN ('OPEN','REVIEWING','AWAITING_FINANCIAL_ACTION') LIMIT 1`,[dispute.jobId]);
    if(active[0]) { const e=new Error('ACTIVE_DISPUTE_EXISTS'); e.code='ACTIVE_DISPUTE_EXISTS'; throw e; }
    const {rows}=await client.query(`INSERT INTO job_disputes(id,job_id,opened_by,against_user_id,reason,details,status,resolution_type,resolution_note,resolved_by,resolved_at,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,[dispute.id,dispute.jobId,dispute.openedBy,dispute.againstUserId,dispute.reason,dispute.details||'',dispute.status||'OPEN',dispute.resolutionType||null,dispute.resolutionNote||'',dispute.resolvedBy||null,dispute.resolvedAt||null,dispute.createdAt,dispute.updatedAt]);
    if(job.status==='DELIVERED') await client.query(`UPDATE jobs SET status='UNDER_REVIEW',updated_at=NOW() WHERE id=$1`,[dispute.jobId]);
    await client.query('COMMIT');
    return mapJobDispute(rows[0]);
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}
export async function createJobDispute(dispute) {
  const {rows}=await requirePool().query(`INSERT INTO job_disputes(id,job_id,opened_by,against_user_id,reason,details,status,resolution_type,resolution_note,resolved_by,resolved_at,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,[dispute.id,dispute.jobId,dispute.openedBy,dispute.againstUserId,dispute.reason,dispute.details||'',dispute.status||'OPEN',dispute.resolutionType||null,dispute.resolutionNote||'',dispute.resolvedBy||null,dispute.resolvedAt||null,dispute.createdAt,dispute.updatedAt]);
  return mapJobDispute(rows[0]);
}
export async function listJobDisputes(status=null) {
  const params=[]; const where=status?(params.push(status),'WHERE d.status=$1'):'';
  const {rows}=await requirePool().query(`SELECT d.*,ou.display_name AS opener_name,au.display_name AS against_name FROM job_disputes d LEFT JOIN users ou ON ou.id=d.opened_by LEFT JOIN users au ON au.id=d.against_user_id ${where} ORDER BY d.created_at DESC LIMIT 500`,params);
  return rows.map(r=>({...mapJobDispute(r),openerName:r.opener_name||null,againstName:r.against_name||null}));
}
export async function updateJobDispute(id, patch) {
  const {rows}=await requirePool().query(`UPDATE job_disputes SET status=COALESCE($2,status),resolution_type=COALESCE($3,resolution_type),resolution_note=COALESCE($4,resolution_note),resolved_by=COALESCE($5,resolved_by),resolved_at=COALESCE($6,resolved_at),updated_at=NOW() WHERE id=$1 RETURNING *`,[id,patch.status||null,patch.resolutionType||null,patch.resolutionNote||null,patch.resolvedBy||null,patch.resolvedAt||null]);
  return rows[0]?mapJobDispute(rows[0]):null;
}

export async function resolveDisputeFinancialAtomic({disputeId,adminId,resolutionType,resolutionNote='',nowIso}) {
  return withSqlTransaction(async(client)=>{
    const {rows:dr}=await client.query(`SELECT * FROM job_disputes WHERE id=$1 FOR UPDATE`,[disputeId]);
    const dispute=dr[0];
    if(!dispute){ const e=new Error('DISPUTE_NOT_FOUND'); e.code='DISPUTE_NOT_FOUND'; throw e; }
    if(dispute.status==='RESOLVED' || dispute.status==='DISMISSED') return {dispute:mapJobDispute(dispute),financialAction:null,alreadyDone:true};
    if(dispute.status==='AWAITING_FINANCIAL_ACTION') {
      if(dispute.resolution_type!==resolutionType){ const e=new Error('DISPUTE_NOT_ACTIONABLE'); e.code='DISPUTE_NOT_ACTIONABLE'; throw e; }
      const {rows:events}=await client.query(`SELECT id,status,payload FROM outbox_events WHERE event_type=$1 AND (payload->>'disputeId')=$2 ORDER BY created_at DESC LIMIT 1`,[resolutionType==='REFUND_OWNER'?'PAYMENT_REFUND':'PAYMENT_RELEASE',disputeId]);
      return {dispute:mapJobDispute(dispute),financialAction:{type:resolutionType,outboxEventId:events[0]?.id||null,status:events[0]?.status||'PENDING'},alreadyDone:false};
    }
    if(!['OPEN','REVIEWING'].includes(dispute.status)){ const e=new Error('DISPUTE_NOT_ACTIONABLE'); e.code='DISPUTE_NOT_ACTIONABLE'; throw e; }
    if(dispute.status==='REVIEWING' && dispute.resolution_type && dispute.resolution_type!==resolutionType){ const e=new Error('DISPUTE_NOT_ACTIONABLE'); e.code='DISPUTE_NOT_ACTIONABLE'; throw e; }
    const nowValue=nowIso || new Date().toISOString();
    if(resolutionType==='NO_ACTION') {
      const {rows}=await client.query(`UPDATE job_disputes SET status='RESOLVED',resolution_type='NO_ACTION',resolution_note=$2,resolved_by=$3,resolved_at=$4,updated_at=NOW() WHERE id=$1 RETURNING *`,[disputeId,resolutionNote,adminId,nowValue]);
      return {dispute:mapJobDispute(rows[0]),financialAction:null,alreadyDone:false};
    }
    if(!['REFUND_OWNER','RELEASE_PROVIDER'].includes(resolutionType)){ const e=new Error('DISPUTE_NOT_ACTIONABLE'); e.code='DISPUTE_NOT_ACTIONABLE'; throw e; }
    const {rows:pr}=await client.query(`SELECT p.*,j.status AS job_status,j.provider_id FROM payments p JOIN jobs j ON j.id=p.job_id WHERE p.job_id=$1 FOR UPDATE`,[dispute.job_id]);
    const payment=pr[0]; if(!payment){ const e=new Error('PAYMENT_REQUIRED'); e.code='PAYMENT_REQUIRED'; throw e; }
    if(payment.status!=='HELD'){ const e=new Error('INVALID_PAYMENT_STATE'); e.code='INVALID_PAYMENT_STATE'; throw e; }
    if(resolutionType==='REFUND_OWNER') {
      const {rows:existingRefund}=await client.query(`SELECT * FROM refunds WHERE payment_id=$1 AND idempotency_key=$2 ORDER BY created_at DESC LIMIT 1`,[payment.id,`dispute-refund:${disputeId}`]);
      const refund=existingRefund[0] || null;
      const refundId=refund?.id || crypto.randomUUID();
      if(!refund) await client.query(`INSERT INTO refunds(id,payment_id,amount,status,provider_ref,idempotency_key,created_at,updated_at) VALUES($1,$2,$3,'PENDING',NULL,$4,$5,$5)`,[refundId,payment.id,payment.amount,`dispute-refund:${disputeId}`,nowValue]);
      else if(refund.status==='FAILED') await client.query(`UPDATE refunds SET status='PENDING',provider_ref=NULL,updated_at=$2 WHERE id=$1`,[refundId,nowValue]);
      else if(refund.status==='REFUNDED'){ const refreshed=(await client.query(`SELECT * FROM job_disputes WHERE id=$1`,[disputeId])).rows[0]; return {dispute:mapJobDispute(refreshed),financialAction:{type:'REFUND_OWNER',refundId,alreadyDone:true},alreadyDone:true}; }
      await client.query(`UPDATE payments SET status='REFUND_PENDING',updated_at=$2 WHERE id=$1`,[payment.id,nowValue]);
      await client.query(`UPDATE job_disputes SET status='AWAITING_FINANCIAL_ACTION',resolution_type='REFUND_OWNER',resolution_note=$2,resolved_by=$3,updated_at=NOW() WHERE id=$1`,[disputeId,resolutionNote,adminId]);
      const dedupe=`PAYMENT_REFUND:DISPUTE:${disputeId}`;
      const {rows:ev}=await client.query(`INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at) VALUES(gen_random_uuid(),'PAYMENT_REFUND','payment',$1,$2,$3::jsonb,'PENDING',0,NOW(),NOW()) ON CONFLICT(dedupe_key) DO UPDATE SET status=CASE WHEN outbox_events.status='DONE' THEN outbox_events.status ELSE 'PENDING' END,attempts=CASE WHEN outbox_events.status='DONE' THEN outbox_events.attempts ELSE 0 END,available_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.available_at ELSE NOW() END,locked_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.locked_at ELSE NULL END,lease_token=CASE WHEN outbox_events.status='DONE' THEN outbox_events.lease_token ELSE NULL END,last_error=CASE WHEN outbox_events.status='DONE' THEN outbox_events.last_error ELSE NULL END,processed_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.processed_at ELSE NULL END RETURNING *`,[payment.id,dedupe,JSON.stringify({jobId:payment.job_id,ownerId:payment.payer_id,paymentId:payment.id,refundId,providerRef:payment.provider_ref,idempotencyKey:`dispute-refund:${disputeId}`,disputeId})]);
      const refreshed=(await client.query(`SELECT * FROM job_disputes WHERE id=$1`,[disputeId])).rows[0];
      return {dispute:mapJobDispute(refreshed),financialAction:{type:'REFUND_OWNER',outboxEventId:ev[0].id,refundId},alreadyDone:false};
    }
    await client.query(`UPDATE jobs SET status='COMPLETED',updated_at=$2 WHERE id=$1`,[payment.job_id,nowValue]);
    await client.query(`UPDATE payments SET status='RELEASE_PENDING',updated_at=$2 WHERE id=$1`,[payment.id,nowValue]);
    await client.query(`UPDATE job_disputes SET status='AWAITING_FINANCIAL_ACTION',resolution_type='RELEASE_PROVIDER',resolution_note=$2,resolved_by=$3,updated_at=NOW() WHERE id=$1`,[disputeId,resolutionNote,adminId]);
    const dedupe=`PAYMENT_RELEASE:DISPUTE:${disputeId}`;
    const {rows:ev}=await client.query(`INSERT INTO outbox_events(id,event_type,aggregate_type,aggregate_id,dedupe_key,payload,status,attempts,available_at,created_at) VALUES(gen_random_uuid(),'PAYMENT_RELEASE','payment',$1,$2,$3::jsonb,'PENDING',0,NOW(),NOW()) ON CONFLICT(dedupe_key) DO UPDATE SET status=CASE WHEN outbox_events.status='DONE' THEN outbox_events.status ELSE 'PENDING' END,attempts=CASE WHEN outbox_events.status='DONE' THEN outbox_events.attempts ELSE 0 END,available_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.available_at ELSE NOW() END,locked_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.locked_at ELSE NULL END,lease_token=CASE WHEN outbox_events.status='DONE' THEN outbox_events.lease_token ELSE NULL END,last_error=CASE WHEN outbox_events.status='DONE' THEN outbox_events.last_error ELSE NULL END,processed_at=CASE WHEN outbox_events.status='DONE' THEN outbox_events.processed_at ELSE NULL END RETURNING *`,[payment.id,dedupe,JSON.stringify({jobId:payment.job_id,ownerId:payment.payer_id,paymentId:payment.id,providerRef:payment.provider_ref,idempotencyKey:`payment-release:${payment.id}`,disputeId})]);
    const refreshed=(await client.query(`SELECT * FROM job_disputes WHERE id=$1`,[disputeId])).rows[0];
    return {dispute:mapJobDispute(refreshed),financialAction:{type:'RELEASE_PROVIDER',outboxEventId:ev[0].id},alreadyDone:false};
  });
}
export async function createReworkRequest(item) {
  const {rows}=await requirePool().query(`INSERT INTO job_rework_requests(id,job_id,requested_by,reason,status,created_at,updated_at,completed_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,[item.id,item.jobId,item.requestedBy,item.reason,item.status||'OPEN',item.createdAt,item.updatedAt,item.completedAt||null]);
  return mapRework(rows[0]);
}
export async function getOpenReworkRequest(jobId) {
  const {rows}=await requirePool().query(`SELECT * FROM job_rework_requests WHERE job_id=$1 AND status='OPEN' ORDER BY created_at DESC LIMIT 1`,[jobId]);
  return rows[0]?mapRework(rows[0]):null;
}
export async function completeReworkRequest(jobId) {
  const {rows}=await requirePool().query(`UPDATE job_rework_requests SET status='COMPLETED',completed_at=NOW(),updated_at=NOW() WHERE job_id=$1 AND status='OPEN' RETURNING *`,[jobId]);
  return rows[0]?mapRework(rows[0]):null;
}
function mapJobReview(r){ return {id:r.id,jobId:r.job_id,reviewerId:r.reviewer_id,revieweeId:r.reviewee_id,reviewerRole:r.reviewer_role,rating:Number(r.rating),comment:r.comment||'',createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}; }
function mapJobDispute(r){ return {id:r.id,jobId:r.job_id,openedBy:r.opened_by,againstUserId:r.against_user_id,reason:r.reason,details:r.details||'',status:r.status,resolutionType:r.resolution_type||null,resolutionNote:r.resolution_note||'',resolvedBy:r.resolved_by||null,resolvedAt:r.resolved_at ? (r.resolved_at.toISOString?.() ?? r.resolved_at) : null,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}; }
function mapRework(r){ return {id:r.id,jobId:r.job_id,requestedBy:r.requested_by,reason:r.reason,status:r.status,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at,completedAt:r.completed_at ? (r.completed_at.toISOString?.() ?? r.completed_at) : null}; }


export async function getLatestProviderVerification(userId) {
  const {rows}=await requirePool().query(`SELECT * FROM provider_verifications WHERE provider_user_id=$1 ORDER BY created_at DESC LIMIT 1`,[userId]);
  return rows[0]?mapProviderVerification(rows[0]):null;
}
export async function createProviderVerificationAtomic(item) {
  return withSqlTransaction(async(client)=>{
    const {rows:uploads}=await client.query(`SELECT id FROM uploads WHERE storage_key=$1 AND uploaded_by=$2`,[item.evidenceUri.slice('storage://'.length),item.providerUserId]);
    if(!uploads[0]) { const e=new Error('INVALID_STORAGE_REFERENCE'); e.code='INVALID_STORAGE_REFERENCE'; throw e; }
    const {rows:active}=await client.query(`SELECT id FROM provider_verifications WHERE provider_user_id=$1 AND status='PENDING' LIMIT 1`,[item.providerUserId]);
    if(active[0]) { const e=new Error('VERIFICATION_ALREADY_PENDING'); e.code='VERIFICATION_ALREADY_PENDING'; throw e; }
    const {rows}=await client.query(`INSERT INTO provider_verifications(id,provider_user_id,document_type,evidence_uri,status,review_note,reviewed_by,reviewed_at,created_at,updated_at) VALUES($1,$2,$3,$4,'PENDING','',NULL,NULL,$5,$6) RETURNING *`,[item.id,item.providerUserId,item.documentType,item.evidenceUri,item.createdAt,item.updatedAt]);
    await client.query(`UPDATE providers SET verification_status='PENDING',updated_at=$2 WHERE user_id=$1`,[item.providerUserId,item.updatedAt]);
    return mapProviderVerification(rows[0]);
  });
}
export async function listProviderVerifications(status=null) {
  const params=[]; const where=status?(params.push(status),'WHERE v.status=$1'):'';
  const {rows}=await requirePool().query(`SELECT v.*,u.display_name AS provider_name FROM provider_verifications v JOIN users u ON u.id=v.provider_user_id ${where} ORDER BY v.created_at DESC LIMIT 500`,params);
  return rows.map(r=>({...mapProviderVerification(r),providerName:r.provider_name||null}));
}
export async function updateProviderVerification(id,status,reviewedBy,reviewNote='') {
  return withSqlTransaction(async(client)=>{
    const {rows}=await client.query(`UPDATE provider_verifications SET status=$2,reviewed_by=$3,review_note=$4,reviewed_at=NOW(),updated_at=NOW() WHERE id=$1 RETURNING *`,[id,status,reviewedBy,reviewNote]);
    if(!rows[0]) return null;
    const providerStatus=status==='APPROVED'?'VERIFIED':'REJECTED';
    await client.query(`UPDATE providers SET verification_status=$2,updated_at=NOW() WHERE user_id=$1`,[rows[0].provider_user_id,providerStatus]);
    return mapProviderVerification(rows[0]);
  });
}
function mapProviderVerification(r){ return {id:r.id,providerUserId:r.provider_user_id,documentType:r.document_type,evidenceUri:r.evidence_uri,status:r.status,reviewNote:r.review_note||'',reviewedBy:r.reviewed_by||null,reviewedAt:r.reviewed_at ? (r.reviewed_at.toISOString?.() ?? r.reviewed_at) : null,createdAt:r.created_at?.toISOString?.() ?? r.created_at,updatedAt:r.updated_at?.toISOString?.() ?? r.updated_at}; }
