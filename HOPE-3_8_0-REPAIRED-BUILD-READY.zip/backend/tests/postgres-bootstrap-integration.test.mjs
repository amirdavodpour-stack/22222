import test from 'node:test';
import assert from 'node:assert/strict';

const enabled = Boolean(process.env.DATABASE_URL);

test('PostgreSQL bootstrap creates every mapped application table and can load state', { skip: !enabled }, async () => {
  process.env.NODE_ENV = 'test';
  process.env.DATA_FILE = '/tmp/hope-empty-test-data.json';
  const { initDatabase, getPool, db } = await import('../src/db.js');
  await initDatabase();
  const pool = getPool();
  const { rows } = await pool.query(`
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema='public' AND table_name = ANY($1::text[])
    ORDER BY table_name`, [[
      'users','providers','refresh_tokens','reset_tokens','categories','jobs','offers','job_applications','payments',
      'ledger_entries','settlements','refunds','payment_webhook_events','evidence','uploads','upload_intents',
      'audit_logs','notifications','notification_preferences','notification_devices','analytics_events','crash_reports','trust_reports',
    ]]);
  assert.equal(rows.length, 22);
  assert.ok(Array.isArray(db.collection.notifications));
  assert.ok(Array.isArray(db.collection.analyticsEvents));
  await db.close();
});
