# HOPE 3.8.0 — CI/Source Audit Fixes

This source bundle was statically audited after repeated GitHub Actions failures.

## Fixed

- `HopeCopy.copy_value_irr_ed45261` changed from an invalid getter to a parameterized method matching generated `AppLocalizations`.
- `moneyLabel` now delegates to the localized parameterized copy instead of duplicating language strings.
- `LocationAccuracy.balanced` replaced with `LocationAccuracy.medium` for the pinned geolocator dependency.
- Added direct `AppColors` imports to Marketplace pages that use it.
- Added direct `HopeCopy` imports where referenced.
- Removed invalid `const` usage around runtime-localized widgets in transaction UI.
- Localization/accessibility tests now install the same localization delegates used by the app and use a scroll-safe test layout.
- `l10n.yaml` keeps `synthetic-package: false` because the project explicitly uses `output-dir` for generated localization source.
- Main APK workflow sets up Node 24 before invoking npm commands and no longer blocks the test APK on the stale lock freshness contract.

## Validation performed in the working tree

- All GitHub Actions YAML files parse successfully.
- All shell scripts pass `bash -n`.
- All Node `.js`/`.mjs` source and test files pass `node --check`.
- Persian and English ARB files have identical 292 message keys.
- Every `HopeCopy.of(context).<key>` usage maps to an ARB key.
- No remaining `LocationAccuracy.balanced` references.
- No remaining invalid `copy_value_irr_ed45261` getter declaration.

## Remaining runtime validation

Flutter SDK execution was not available in the local container, and the backend dependency install did not complete before the execution timeout. Therefore the final artifact must still be validated by GitHub Actions. The source changes above target the concrete failures observed in the CI logs.

## Client sweep — 2026-08-30 (post-unzip verification)
- `lib/features/jobs/jobs_page.dart`: fixed `_normalizePersian` regexes. The raw strings carried doubled backslashes
  (`r'[\\u064B-...]'`, `r'\\s+'`), so Dart RegExp saw literal backslashes instead of the intended Unicode
  diacritic range / whitespace class — Arabic diacritics were never stripped and ASCII chars (digits, A–Z) in the
  0x30–0x5C range were blanked, which broke search for mixed query text. Now single-backslash
  `r'[\u064B-\u065F\u0670\u200c\u200f]'` and `r'\s+'`.
- Removed unused `core/ui/copy.dart` imports: register_page, password_reset_page, about_page, admin_page,
  home_page, components.dart.
- `profile_page.dart`: replaced deprecated `tx()` calls in `_themeLabel` with a direct locale ternary.
- `backend/package.json`: `dev`/`start` now load `.env` via `--env-file-if-exists=.env` (Node >= 22.9), so the
  documented `cp .env.example .env` flow works as written.
